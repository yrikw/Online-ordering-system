<?php
require_once __DIR__."/site.php";
require_once __DIR__."/admin.php";
