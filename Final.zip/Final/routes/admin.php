<?php

// admin
$router->get('/admin/dashboard', "admin\DashboardController@index");

// products
$router->get('/admin/products', "admin\ProductController@index");
$router->get('/admin/products', "admin\ProductController@index");
$router->get('/admin/products/save', "admin\ProductController@saveIndex");
$router->post('/admin/products/save', "admin\ProductController@save");
$router->get('/admin/products/delete', "admin\ProductController@delete");

// customer
$router->get('/admin/customer', "admin\CustomerController@index");
$router->get('/admin/customer', "admin\CustomerController@index");
$router->get('/admin/customer/save', "admin\CustomerController@saveIndex");
$router->post('/admin/customer/save', "admin\CustomerController@save");
$router->get('/admin/customer/delete', "admin\CustomerController@delete");

// staff
$router->get('/admin/staff', "admin\StaffController@index");
$router->get('/admin/staff', "admin\StaffController@index");
$router->get('/admin/staff/save', "admin\StaffController@saveIndex");
$router->post('/admin/staff/save', "admin\StaffController@save");
$router->get('/admin/staff/delete', "admin\StaffController@delete");

// feedback
$router->get('/admin/feedback', "admin\FeedbackController@index");
$router->get('/admin/feedback', "admin\FeedbackController@index");
$router->get('/admin/feedback/save', "admin\FeedbackController@saveIndex");
$router->post('/admin/feedback/save', "admin\FeedbackController@save");

// orders
$router->get('/admin/orders', "admin\OrderController@index");
$router->get('/admin/orders', "admin\OrderController@index");
$router->get('/admin/orders/save', "admin\OrderController@saveIndex");
$router->post('/admin/orders/save', "admin\OrderController@save");

// suppliers
$router->get('/admin/suppliers', "admin\SupplierController@index");
$router->get('/admin/suppliers', "admin\SupplierController@index");
$router->get('/admin/suppliers/save', "admin\SupplierController@saveIndex");
$router->post('/admin/suppliers/save', "admin\SupplierController@save");

//stock history
$router->get('/admin/stock_history', "admin\StockHistoryController@index");
$router->get('/admin/stock_history', "admin\StockHistoryController@index");
$router->get('/admin/stock_history/save', "admin\StockHistoryController@saveIndex");
$router->post('/admin/stock_history/save', "admin\StockHistoryController@save");

//pages
$router->get('/admin/pages', "admin\PageController@index");
$router->get('/admin/pages', "admin\PageController@index");
$router->get('/admin/pages/save', "admin\PageController@saveIndex");
$router->post('/admin/pages/save', "admin\PageController@save");

$router->get('/admin/login', "admin\AuthController@loginIndex");
$router->post('/admin/login', "admin\AuthController@login");
$router->get('/admin/logout', "admin\AuthController@logout");

// report
$router->get('/admin/daily-report', "admin\DashboardController@dailyReport");
$router->get('/admin/weekly-report', "admin\DashboardController@weeklyReport");
$router->get('/admin/monthly-report', "admin\DashboardController@monthlyReport");


//job types
$router->get('/admin/type', "admin\JobTypeController@index");
$router->get('/admin/type', "admin\JobTypeController@index");
$router->get('/admin/type/save', "admin\JobTypeController@saveIndex");
$router->post('/admin/type/save', "admin\JobTypeController@save");
