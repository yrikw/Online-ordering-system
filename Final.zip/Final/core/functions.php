<?php

use app\models\Cart;
use app\models\Wishlist;
use core\Email;

function filePath($file_path){
    if(substr($file_path, 0, 1) == "/"){
        $file_path = substr($file_path, 1);
    }
    return rootPath."/".$file_path;
}
function dd(...$args){
    foreach($args as $arg){
        echo "<div style='background-color: #000; color: #fff; padding: 10px;border'><pre>";
        print_r($arg);
        echo "</pre></div>";
    }
    die();
}
function public_path($path=""){
    return "/$path";
}
function url($path){
    return "/$path";
}

function load_json($file_path){
    $file = fopen(filePath($file_path), "r") or die("Unable to open file!");
    $data= json_decode(fread($file, filesize(filePath($file_path))), true);
    fclose($file);
    return $data;
}
function component($component, $data=[]){
    $url =str_replace(".", "/", $component);
    $file = filePath("views/".$url.".php");
    if(file_exists($file)){
        extract($data);
        include $file;
    }
}
function toOptionList($items, $key, $value,$extraVal="") {
    $options = [];
    foreach ($items as $item) {
        if (is_object($item)) {
            $item = (array) $item;
        }
        $full = $item[$value];
        if ($extraVal != "") {
            $full .= " " . $item[$extraVal];
        }
        $options[] =[
            "value" => $item[$key],
            "label" => $full
        ];
    }
    return $options;
}

function checkbox($attribute){
    return $attribute == "on" ? 1 : 0;
}

function form_status(){
    $status = "";
    if(isset($_SESSION["form_status"])){
        $status = $_SESSION["form_status"];
        unset($_SESSION["form_status"]);
        $message = @$status['message']??'';
        if (@$status['type'] == "success"){
            return "
              <div class='alert alert-success alert-dismissible fade show' role='alert'>
                <strong>Success!</strong> {$message}
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
              </div>
            ";
        }else{
            return "
              <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                <strong>Error!</strong> {$message}
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
              </div>
            ";
        }
    }
}

function authAdminMiddleware(){
    $loginPath=url("admin/login");
    if(!isset($_SESSION["auth"]) && $_SESSION["auth"]["role"] != "admin"){
        header("Location: $loginPath");
    }
}
function authUserMiddleware(){
    $loginPath=url("login");
    if(!isset($_SESSION["auth"]) && $_SESSION["auth"]["role"] != "customer"){
        header("Location: $loginPath");
    }
}
function authUser(){
    return  @$_SESSION["auth"]["user"];;
}
function checkAuth(){
    return isset($_SESSION["auth"]);
}

function blogToBase64($blob){
    return "data:image/png;base64,".base64_encode($blob);
}

function checkCartExists($product_id){
    $cartModel = new Cart();
    return $cartModel->where("product_id",$product_id)->where("customer_id",@authUser()->customer_id)->first();
}

function checkWishlistExists($product_id){
    $wishlistModel = new Wishlist();
    return $wishlistModel->where("product_id",$product_id)->where("customer_id",@authUser()->customer_id)->first();
}
function env(){
    return load_json("env.json");
}
function sendEmail($to, $subject, $message){
    $email = new Email();
    $email->send($to->email,$to->first_name." ".$to->last_name,$subject,$message);
}