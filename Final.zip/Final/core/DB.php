<?php
namespace core;
use core\classes\PDO;

class DB{
    protected $pdo;
    public $table;
    protected $primaryKey = "id";
    protected $fillable = [];
    protected $hidden = [];
    protected $casts = [];
    private $returnType = \PDO::FETCH_OBJ;
    protected $timestamps = true;
    protected $where = [];
    protected $whereValues = [];
    protected $limit = 0;
    protected $offset = 0;
    protected $orderBy = null;
    protected $groupBy = null;
    protected $whereTypes = ["and", "or",'in', 'not_in','between', 'not_between', 'like', 'not_like', 'is_null', 'is_not_null'];
    protected $action = "select";

    protected $values = [];
    protected $requestDate = [];


    public function __construct()
    {
        $host = DB_HOST;
        $user = DB_USER;
        $password = DB_PASSWORD;
        $db_name = DB_NAME;
        $this->pdo = new \PDO("mysql:host=$host;dbname=$db_name", $user, $password);
    }
    public function  getSelect(){
        $fillable = $this->fillable;
        foreach ($this->hidden as $hidden){
            if(($key = array_search($hidden, $fillable)) !== false) {
                unset($fillable[$key]);
            }
        }
        return implode(",", $fillable);
    }

    public function where($key, $value)
    {
        $this->where[] = [
            "key" => $key,
            "value" => $value,
            "type" => "and"
        ];
        return $this;
    }
    public function whereOr($key, $value)
    {
        $this->where[] = [
            "key" => $key,
            "value" => $value,
            "type" => "or"
        ];
        return $this;
    }
    public function whereIn($key, $value)
    {
        $this->where[] = [
            "key" => $key,
            "value" => $value,
            "type" => "in"
        ];
        return $this;
    }
    public function whereNotIn($key, $value)
    {
        $this->where[] = [
            "key" => $key,
            "value" => $value,
            "type" => "not_in"
        ];
        return $this;
    }
    public function whereBetween($key, $value)
    {
        $this->where[] = [
            "key" => $key,
            "value" => $value,
            "type" => "between"
        ];
        return $this;
    }
    public function whereNotBetween($key, $value)
    {
        $this->where[] = [
            "key" => $key,
            "value" => $value,
            "type" => "not_between"
        ];
        return $this;
    }
    public function whereLike($key, $value)
    {
        $this->where[] = [
            "key" => $key,
            "value" => $value,
            "type" => "like"
        ];
        return $this;
    }
    public function whereNotLike($key, $value)
    {
        $this->where[] = [
            "key" => $key,
            "value" => $value,
            "type" => "not_like"
        ];
        return $this;
    }
    public function whereNull($key)
    {
        $this->where[] = [
            "key" => $key,
            "value" => null,
            "type" => "is_null"
        ];
        return $this;
    }
    public function whereNotNull($key)
    {
        $this->where[] = [
            "key" => $key,
            "value" => null,
            "type" => "is_not_null"
        ];
        return $this;
    }

    public function getWhere(){
        $where = "";
        foreach ($this->where as $key => $value){
            if($key == 0){
                $where .= " WHERE ";
            }else{
                $where .= " {$value['type']} ";
            }
            if($value['type'] == "in" || $value['type'] == "not_in"){
                $where .= "{$value['key']} {$value['type']} (";
                $where .= implode(",", $value['value']);
                $where .= ")";
            }elseif ($value['type'] == "between" || $value['type'] == "not_between"){
                $where .= "{$value['key']} {$value['type']} {$value['value'][0]} AND {$value['value'][1]}";
            }elseif ($value['type'] == "is_null" || $value['type'] == "is_not_null"){
                $where .= "{$value['key']} {$value['type']}";
            }else{
                $where .= "{$value['key']} = :{$value['key']}";
            }
            $this->whereValues[$value['key']] = $value['value'];
        }
        return $where;
    }
    public function limit($limit)
    {
        $this->limit = $limit;
        return $this;
    }
    public function orderBy($attribute, $order = "ASC")
    {
        $this->orderBy= [
            "attribute" => $attribute,
            "order" => $order
        ];
        return $this;
    }
    public function orderByDesc($attribute)
    {
        $this->orderBy= [
            "attribute" => $attribute,
            "order" => "DESC"
        ];
        return $this;
    }
    public function orderByAsc($attribute)
    {
        $this->orderBy= [
            "attribute" => $attribute,
            "order" => "ASC"
        ];
        return $this;
    }

    public function groupBy($attribute)
    {
        $this->groupBy= $attribute;
        return $this;
    }
    public function getSql(){
        $select = $this->getSelect();
        $where = $this->getWhere();
        $orderBy = "";
        $groupBy = "";
        $limit = "";

        if($this->orderBy){
            $orderBy = " ORDER BY {$this->orderBy['attribute']} {$this->orderBy['order']}";
        }
        if($this->groupBy){
            $groupBy = " GROUP BY {$this->groupBy}";
        }
        if($this->limit){
            $limit = " LIMIT {$this->limit}";
        }
        $fields = array_keys($this->values??[])??[];
        $values = array_values($this->values??[])??[];
        switch ($this->action){
            case "insert":
                $sql = "INSERT INTO $this->table (".implode(",", $fields).") VALUES (:".implode(",:", $fields).")";
                break;
            case "update":
                $sql = "UPDATE $this->table SET ";
                foreach($fields as $key=>$value){
                    $sql .= "$value = :$value,";
                }
                $sql = rtrim($sql, ",");
                $sql .= $where;
                break;
            case "delete":
                $sql = "DELETE FROM $this->table $where";
                break;
            default:
                $sql = "SELECT $select FROM $this->table $where $groupBy $orderBy $limit";
                break;
        }
        return $sql;
    }
    public  function exeQuery(){
        $sql = $this->getSql();
        $stmt = $this->pdo->prepare($sql);
        $values = array_merge($this->values??[], $this->whereValues??[]);
        $stmt->execute($values);
        return $stmt;
    }

    public function all()
    {
        $select = $this->getSelect();
        $sql = "SELECT $select FROM $this->table";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll($this->returnType);
    }
    public function find($id)
    {
        $primaryKey = $this->primaryKey;
        foreach ($this->where as $key => $value){
            if($value['key'] == $primaryKey){
                unset($this->where[$key]);
            }
        }
        $this->where($primaryKey, $id);
        return $this->exeQuery()->fetch($this->returnType);
    }

    public function get()
    {
        return $this->exeQuery()->fetchAll($this->returnType);
    }

    public function first()
    {
        return $this->exeQuery()->fetch($this->returnType);
    }
    public function reset()
    {
        $this->select = "*";
        $this->where = [];
        $this->whereValues = [];
        $this->limit = null;
        $this->orderBy = null;
        $this->groupBy = null;
        $this->action = null;
        $this->values = null;
        return $this;
    }

    public function mutationQuery($data)
    {
        $values =[];
        foreach ($data as $key => $value){
            if(in_array($key, $this->fillable)){
                $values[$key] = $value;
            }
        }
        $this->values = $values;
        $this->exeQuery();
        $lastId = $this->pdo->lastInsertId();
        $this->reset();
        return $this->find($lastId);
    }

    public function create($data)
    {
        $this->action = "insert";
        return $this->mutationQuery($data);
    }
    public function update($id,$data)
    {
        $this->where($this->primaryKey, $id);
        $this->action = "update";
        return $this->mutationQuery($data);
    }
    public function delete($id)
    {
        try {
            $this->action = "delete";
            $this->where($this->primaryKey, $id);
            $this->exeQuery();
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }
    public  function setReturnTypeArr(){
//       odp only fetch values array
        $this->returnType  =\PDO::FETCH_ASSOC;
    }

    public function getHeaders($collection)
    {
        $tr=[];
        foreach ($collection as $item){
            $tr[] =  $item['field'];
        }
        return $tr;
    }
    public  function  process($rows,$select=[]){
        $tr = $this->getHeaders($select);
        $items = [];
        foreach ($rows as $row){
            if($select !=[]){
                $item = [];
                foreach ($row as $key => $value){
                    if (in_array($key, $tr)){
                        $item[$key] = $value;
                    }
                }
                $items[] = $item;
            }else{
                $items[] = $row;
            }
        }
        return $items;
    }

    public function getIdAttribute()
    {
        return $this->primaryKey;
    }

    public function count()
    {
        $sql = "SELECT COUNT(*) as count FROM $this->table ".$this->getWhere();
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($this->whereValues);
        return $stmt->fetch(\PDO::FETCH_OBJ)->count;
    }

    public function rawQuery($sql,$data=[])
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($data);
        return $stmt;
    }
}