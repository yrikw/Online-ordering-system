<?php
namespace core;

class Route{
    public $prefix = "";
    public $routes = [];
    public $current_uri;
    public function __construct($prefix = "")
    {
        $script_filename = $_SERVER["SCRIPT_FILENAME"];
        $request_uri = $_SERVER["REQUEST_URI"];
        $script_filename = str_replace("/public/index.php", "", $script_filename);
        $script_filename_arr = explode("/", $script_filename);
        $root_folder = $script_filename_arr[count($script_filename_arr) - 1];
        $current_path = str_replace("/".$root_folder, "", $request_uri);
        $current_path= explode("?", $current_path)[0];
        $this->current_uri = $current_path;
    }

    private  function  addRoute($method, $uri, $callback){
        if(substr($uri, 0, 1) == "/"){
            $uri = substr($uri, 1);
        }
        $uri = $this->prefix."/".$uri;
        $this->routes[] = [
            "method" => $method,
            "uri" => $uri,
            "callback" => $callback
        ];
    }

    public function get($uri, $callback){
        $this->addRoute("GET", $uri, $callback);
    }
    public function post($uri, $callback){
        $this->addRoute("POST", $uri, $callback);
    }
    public function put($uri, $callback){
        $this->addRoute("PUT", $uri, $callback);
    }
    public function delete($uri, $callback){
        $this->addRoute("DELETE", $uri, $callback);
    }
    public function patch($uri, $callback){
        $this->addRoute("PATCH", $uri, $callback);
    }

    public function handle(){
        $current_uri = $this->current_uri;
        $method = $_SERVER["REQUEST_METHOD"];
        $routes = $this->routes;
        $callback = null;
        foreach ($routes as $route){
            $route_uri = $route["uri"];
            $route_method = $route["method"];
            if($route_uri == $current_uri && $route_method == $method){
                $callback = $route["callback"];
                break;
            }
        }
        if($callback != null){
            //  check if callback is a function
            if(is_callable($callback)){
                $this->handelRender($callback());
                return;
            }else{
                $callback = explode("@", $callback);
                $controller = $callback[0];
                $action = $callback[1];
                $controller = "app\\controllers\\".$controller;
                $controller = new $controller;
                $this->handelRender($controller->$action());
                return;
            };
        }else{
            echo "404";
        }
    }

    public function handelRender($rtnData)
    {
        if(is_array($rtnData)){
            $rtnData = json_encode($rtnData);
            echo $rtnData;
        }else if(is_string($rtnData)){
            $split = explode("|", $rtnData);
            if(@$split[1]=='view'){
                $data = $GLOBALS["extractableData"];
                extract($data);
                return require_once $split[0];
            }else{
                echo $rtnData;
                return;
            }
        }
    }

    public function __destruct()
    {
        $this->handle();
    }

}