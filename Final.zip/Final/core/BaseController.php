<?php
namespace core;

class BaseController{
    public function view($view, $data = [])
    {
        $view = str_replace(".", "/", $view);
        $view = rootPath . "/views/" . $view . ".php";
        if(file_exists($view)){
            global  $extractableData;
            $extractableData = $data;
            return $view."|view";
        }
        throw new \Exception("View not found");
    }

    public function redirect($url,$data=[])
    {
        try {
            $url = url($url);
            if (isset($data["message"])) {
                $_SESSION["form_status"] = $data;
            }
            header("Location: $url");
        } catch (\Exception $e) {
            throw new \Exception("Redirect error");
        }
        return $this;
    }

    public function uploadFile($name, $path = "uploads") {
        // Check if file was uploaded successfully
        if ($_FILES[$name]['error'] === UPLOAD_ERR_OK) {
            $filename = $_FILES[$name]['name'];
            $tmpFilePath = $_FILES[$name]['tmp_name'];

            // Create the directory if it doesn't exist
            if (!is_dir(rootPath . '/public/' . $path)) {
                mkdir(rootPath . '/public/' . $path, 0777, true);
            }

            // Generate a unique filename to avoid conflicts
            $extension = pathinfo($filename, PATHINFO_EXTENSION);
            $newFilename = uniqid() . '.' . $extension;
            $destination = $path . '/' . $newFilename;

            // Move the uploaded file to the destination directory
            if (move_uploaded_file($tmpFilePath,rootPath . '/public/' .$destination)) {
                return $destination;
            } else {
                return false; // File upload failed
            }
        } else {
            return false; // File upload error
        }
    }

    public  function getPrefix(){
        $prefix = $this->model->table;
        $prefix =explode(" ",$prefix);
        $prefix = implode("_",$prefix);
        return $prefix;
    }

    public function index()
    {
        $prefix = $this->getPrefix();
        return $this->view("admin.pages.$prefix.index",[
            'model' => $this->model,
        ]);
    }
    public function saveIndex()
    {
        $prefix = $this->getPrefix();
        return $this->view("admin.pages.$prefix.save",[
            'model' => $this->model,
        ]);
    }
    public  function save(){
        $request =$_POST;
        $prefix = $this->getPrefix();
        if (isset($request[$this->model->getIdAttribute()]) && $request[$this->model->getIdAttribute()] != ""){
            $this->model->update($request[$this->model->getIdAttribute()], $request);
            return $this->redirect("admin/$prefix",[
                "message" => "$prefix updated successfully",
                "type" => "success"
            ]);
        }else{
            unset($request[$this->model->getIdAttribute()]);
            $this->model->create($request);
            return $this->redirect("admin/$prefix",[
                "message" => "$prefix created successfully",
                "type" => "success"
            ]);
        }
    }
    public function delete(){
        $prefix = $this->getPrefix();
        try {
            $id = $_GET["id"];
            $this->model->delete($id);
            return $this->redirect("admin/$prefix",[
                "message" => "$prefix deleted successfully",
                "type" => "success"
            ]);
        }catch (\Exception $exception){
            return $this->redirect("admin/$prefix",[
                "message" => $exception->getMessage(),
                "type" => "danger"
            ]);
        }
    }

}