<?php
namespace core;
class Kernal{
    public function __construct()
    {
        $this->init_autoloader();
        $this->load_utils();
        $this->load_env();
        $this->load_route();
    }
    public  function load_env(){
        $env = load_json("env.json");
        $db = $env["database"];
        define("DEBUG", $env["debug"]);
        define("DB_HOST", $db["host"]);
        define("DB_USER", $db["user"]);
        define("DB_PASSWORD", $db["password"]);
        define("DB_NAME", $db["db_name"]);
    }
    public function load_route(){
        $router = new Route;
        require_once __DIR__ . '/../routes/web.php';
    }
    public  function load_utils(){
        require_once __DIR__ . '/functions.php';
    }
    public  function  init_autoloader(){
        spl_autoload_register(function ($class_name) {
            $class_name = rootPath . "/" . str_replace("\\", "/", $class_name) . ".php";
            if(file_exists($class_name)){
                require_once $class_name;
            }
        });
    }
}