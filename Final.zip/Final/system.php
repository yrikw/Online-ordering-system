<?php
const rootPath = __DIR__;
require_once 'core/Kernal.php';
require_once __DIR__ . '/vendor/autoload.php';
new \core\Kernal();