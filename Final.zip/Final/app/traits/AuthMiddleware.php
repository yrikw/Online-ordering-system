<?php

namespace app\traits;

trait AuthMiddleware
{
    public function  __construct()
    {
        authAdminMiddleware();
    }

}