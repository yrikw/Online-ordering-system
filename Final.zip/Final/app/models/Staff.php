<?php

namespace app\models;
use core\DB;

class Staff extends DB {
    protected $primaryKey = "staff_id";
    public $table="staff";
    protected $fillable=[
        'staff_id', 'family_name', 'first_name', 'phone_no', 'email', 'qualification_id', 'password',
        'working_hour', 'pay'
    ];
}