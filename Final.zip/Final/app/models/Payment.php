<?php

namespace app\models;
use core\DB;

class Payment extends DB {
    protected $primaryKey = "payment_id";
    public $table="payment";
    protected $fillable=[
        'payment_id', 'payment_date', 'customer_id', 'order_id', 'amount_paid', 'card_number', 'exp_date', 'cvv'
    ];
}