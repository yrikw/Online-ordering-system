<?php

namespace app\models;
use core\DB;

class Supplier extends DB {
    protected $primaryKey = "supplier_id";
    public $table="suppliers";
    protected $fillable=[
        'supplier_id', 'name', 'phone_no', 'registration_no', 'email', 'address'
    ];
}