<?php

namespace app\models;
use core\DB;

class OrderItem extends DB {
    protected $primaryKey = "id";
    public $table="order_items";
    protected $fillable=[
        'id','product_id','order_id','quantity'
    ];
}