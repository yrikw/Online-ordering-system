<?php

namespace app\models;
use core\DB;

class Page extends DB {
    protected $primaryKey = "id";
    public $table="pages";
    protected $fillable=[
        'id', 'title', 'content','slug'
    ];
}