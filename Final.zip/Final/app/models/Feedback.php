<?php

namespace app\models;
use core\DB;

class Feedback extends DB {
    protected $primaryKey = "feedback_id";
    public $table="feedback";
    protected $fillable=[
        'feedback_id', 'title', 'feedback', 'customer_id', 'product_id'
    ];
}