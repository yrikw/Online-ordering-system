<?php

namespace app\models;
use core\DB;

class Product extends DB {
    protected $primaryKey = "product_id";
    public $table="products";
    protected $fillable=[
        'product_id', 'name', 'price', 'description', 'expiry_date', "mfg_date", 'supplier_id', 'category_id', 'weekly_sale', 'quantity', 'Featureed_product', 'image_pathlocation'
    ];
}