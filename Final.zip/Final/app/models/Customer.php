<?php

namespace app\models;
use core\DB;

class Customer extends DB {
    protected $primaryKey = "customer_id";
    public $table="customer";
    protected $fillable=[
        'customer_id', 'family_name', 'first_name', 'phone_no', 'email', 'address', 'date_of_birth', 'job_type_id', 'password','reset_code'
    ];
}