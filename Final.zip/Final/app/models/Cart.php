<?php

namespace app\models;
use core\DB;

class Cart extends DB {
    protected $primaryKey = "cart_id";
    public $table="cart";
    protected $fillable=[
        'cart_id',
        'customer_id',
        'number_of_items',
        'quantity',
        'product_id',
        'total_price'
    ];
}