<?php

namespace app\models;
use core\DB;

class Qualification extends DB {
    protected $primaryKey = "qualification_id";
    public $table="qualification";
    protected $fillable=[
        'qualification_id', 'name'
    ];
}