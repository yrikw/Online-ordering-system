<?php

namespace app\models;
use core\DB;

class StockHistory extends DB {
    protected $primaryKey = "history_id";
    public $table="stock_history";
    protected $fillable=[
        'history_id', 'supplier_id', 'product_id', 'stock_date', 'amount'
    ];
}