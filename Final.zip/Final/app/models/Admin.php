<?php

namespace app\models;
use core\DB;

class Admin extends DB {
    protected $primaryKey = "admin_id";
    public $table="admin";
    protected $fillable=[
        'admin_id', 'family_name', 'last_name', 'phone_no', 'email', 'password'
    ];
}