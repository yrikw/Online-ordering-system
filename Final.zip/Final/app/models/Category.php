<?php

namespace app\models;
use core\DB;

class Category extends DB {
    protected $primaryKey = "category_id";
    public $table="category";
    protected $fillable=[
        'category_id', 'name', 'images'
    ];
}