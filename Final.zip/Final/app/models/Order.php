<?php

namespace app\models;
use core\DB;

class Order extends DB {
    protected $primaryKey = "order_id";
    public $table="orders";
    protected $fillable=[
        'order_id', 'customer_id', 'order_date', 'discount', 'delivery', 'pickup_date', 'time', 'staff_id','status'
    ];
}