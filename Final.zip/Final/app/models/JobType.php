<?php

namespace app\models;
use core\DB;

class JobType extends DB {
    protected $primaryKey = "job_type_id";
    public $table="type";
    protected $fillable=[
        'job_type_id', 'name'
    ];
}