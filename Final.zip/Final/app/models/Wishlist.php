<?php

namespace app\models;
use core\DB;

class Wishlist extends DB {
    protected $primaryKey = "wishlist_id";
    public $table="wishlists";

    protected $fillable=[
        'wishlist_id', 'customer_id', 'product_id', 'number_of_items'
    ];
}