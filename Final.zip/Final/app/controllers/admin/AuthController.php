<?php
namespace app\controllers\admin;
use app\models\Admin;
use core\BaseController;

class  AuthController extends  BaseController{
    public function loginIndex()
    {
        return $this->view("admin.pages.auth.login");
    }

    public  function login()
    {
        $model =new Admin();
        $admin = $model->where("email", $_POST['email'])->first();
        if($admin){
            if(password_verify($_POST['password'], $admin->password)){
                $_SESSION['auth'] = [
                    "user"=>$admin,
                    "role"=>"admin"
                ];
                return $this->redirect("admin/dashboard");
            }else{
                return $this->redirect("admin/login",[
                    "message"=>"Invalid password",
                    "type"=>"danger"
                ]);
            }
        }else{
            return $this->redirect("admin/login",[
                "message"=>"Invalid email",
                "type"=>"danger"
            ]);
        }
    }
    public  function logout(){
        session_destroy();
        return $this->redirect("admin/login");
    }
}