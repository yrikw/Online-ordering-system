<?php

namespace app\controllers\admin;

use app\models\Product;
use app\traits\AuthMiddleware;
use core\BaseController;

class ProductController extends BaseController
{
    use AuthMiddleware;

    protected $model;

    public function __construct()
    {
        $this->authAdminMiddleware();
        $this->model = new Product();
    }

    public function save()
    {
        $request = $_POST;
        $request['Featured_product'] = checkbox(@$request['Featured_product']);
        
        if (isset($_FILES['image_pathlocation']) && $_FILES['image_pathlocation']['name'] != "") {
            $request['image_pathlocation'] = $this->uploadFile('image_pathlocation');
        }
        
        if (isset($request[$this->model->getIdAttribute()]) && $request[$this->model->getIdAttribute()] != "") {
            $this->model->update($request[$this->model->getIdAttribute()], $request);
            return $this->redirect("admin/products", [
                "message" => "Product updated successfully",
                "type" => "success"
            ]);
        } else {
            unset($request[$this->model->getIdAttribute()]);
            $this->model->create($request);
            return $this->redirect("admin/products", [
                "message" => "Product created successfully",
                "type" => "success"
            ]);
        }
    }
    
    protected function authAdminMiddleware()
    {
        // Perform your authentication logic here
        session_start();

        // Check if the user is logged in and has the admin role
        if (!isset($_SESSION['auth']) || $_SESSION['auth']['role'] !== 'admin') {
            // Redirect the user to the login page or show an access denied message
            header("Location: /admin/login");
            exit();
        }
    }
}
