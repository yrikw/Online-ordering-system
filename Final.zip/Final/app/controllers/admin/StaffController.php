<?php

namespace app\controllers\admin;

use app\models\Staff;
use app\traits\AuthMiddleware;
use core\BaseController;

class StaffController extends BaseController
{
    use AuthMiddleware;

    protected $model;

    public function __construct()
    {
        $this->authAdminMiddleware();
        $this->model = new Staff();
    }

    protected function authAdminMiddleware()
    {
        // Perform your authentication logic here
        session_start();

        // Check if the user is logged in and has the admin role
        if (!isset($_SESSION['auth']) || $_SESSION['auth']['role'] !== 'admin') {
            // Redirect the user to the login page or show an access denied message
            header("Location: /admin/login");
            exit();
        }
    }
}
