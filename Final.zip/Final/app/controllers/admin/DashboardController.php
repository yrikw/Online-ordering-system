<?php
namespace app\controllers\admin;
use app\models\Customer;
use app\models\Order;
use app\models\Product;
use app\traits\AuthMiddleware;
use core\BaseController;
use core\DB;

class  DashboardController extends  BaseController{
    public function  __construct()
    {
        authAdminMiddleware();
    }
    public function index()
    {
        $productModel = new Product();
        $customerModel = new Customer();
        $orderModel = new Order();
        $reports =[
            "products" => $productModel->count(),
            "customers" => $customerModel->count(),
            "orders" => $orderModel->count(),
        ];
        return $this->view("admin.pages.index",[
            "reports" => $reports
        ]);
    }

    public function dailyReport()
    {
        $db = new DB();
        $order = $db->rawQuery("SELECT * FROM orders WHERE created_at >= DATE(NOW()) - INTERVAL 1 DAY")->fetchAll(\PDO::FETCH_ASSOC)??[];
        $customer = $db->rawQuery("SELECT * FROM customer WHERE created_at >= DATE(NOW()) - INTERVAL 1 DAY")->fetchAll(\PDO::FETCH_ASSOC)??[];
        $length =  (count($order) + count($customer)  )/ 2;
        return $this->view('admin.pages.reports.daily',[
            "orders" => $order,
            "customers" => $customer,
            "length" => $length
        ]);
    }

    public function weeklyReport()
    {
        $db = new DB();
        $order = $db->rawQuery("SELECT * FROM orders WHERE created_at >= DATE(NOW()) - INTERVAL 7 DAY")->fetchAll(\PDO::FETCH_ASSOC)??[];
        $customer = $db->rawQuery("SELECT * FROM customer WHERE created_at >= DATE(NOW()) - INTERVAL 7 DAY")->fetchAll(\PDO::FETCH_ASSOC)??[];
       $length =  (count($order) + count($customer))/ 2;
        return $this->view('admin.pages.reports.weekly',[
            "orders" => $order,
            "customers" => $customer,
            "length" => $length
        ]);
        
    }

    public function monthlyReport()
    {
        $db = new DB();
        $order = $db->rawQuery("SELECT * FROM orders WHERE created_at >= DATE(NOW()) - INTERVAL 30 DAY")->fetchAll(\PDO::FETCH_ASSOC)??[];
        $customer = $db->rawQuery("SELECT * FROM customer WHERE created_at >= DATE(NOW()) - INTERVAL 30 DAY")->fetchAll(\PDO::FETCH_ASSOC)??[];
        $length =  (count($order) + count($customer))/ 2;
        return $this->view('admin.pages.reports.monthly',[
            "orders" => $order,
            "customers" => $customer,
            "length" => $length
        ]);
    }

    public function profile()
    {
        return $this->redirect("orders");
    }

}