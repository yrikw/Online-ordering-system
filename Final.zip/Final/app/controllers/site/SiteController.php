<?php
namespace app\controllers\site;
use app\models\Cart;
use app\models\Customer;
use app\models\Feedback;
use app\models\Order;
use app\models\OrderItem;
use app\models\Page;
use app\models\Payment;
use app\models\Product;
use app\models\Wishlist;
use core\BaseController;

class  SiteController extends  BaseController
{
    public function home()
    {
        $productModel = new Product();
        $products = $productModel->where('Featureed_product', 1)->all();
        return $this->view("site.pages.index", [
            "products" => $products
        ]);
    }

    public function about()
    {
        return $this->view("site.pages.about");
    }

    public function page()
    {
        $pageModel = new Page();
        $page = $pageModel->where("id", $_GET['id'])->first();
        return $this->view("site.pages.page", [
            "page" => $page
        ]);
    }

    public function dashboard()
    {
        authUserMiddleware();
        return $this->view("site.pages.dashboard");
    }

    public function addToCart()
    {
        if (!checkAuth()) {
            $this->redirect("login");
        }
        $product_id = $_GET['id'];
        $quantity = $_GET['quantity'] ?? 1;
        $productModel = new Product();
        $product = $productModel->find($product_id);
        if (!$product) {
            $this->redirect("home", [
                "message" => "Product not found",
                "type" => "danger"
            ]);
        }
        $cartModel = new Cart();
        if ($cartModel->where("product_id", $product_id)->where("customer_id", authUser()->customer_id)->first()) {
            $this->redirect("cart", [
                "message" => "Product already exists in cart",
                "type" => "danger"
            ]);
        }
        $cartModel = new Cart();
        $cart = $cartModel->create([
            "customer_id" => authUser()->customer_id,
            "product_id" => $product->product_id,
            "quantity" => $quantity,
            "total_price" => $product->price * $quantity
        ]);
        $this->redirect("cart", [
            "message" => "Product added to cart",
            "type" => "success"
        ]);
    }

    public function removeFromCart()
    {
        if (!checkAuth()) {
            $this->redirect("login");
        }
        $cartModel = new Cart();
        $cart = $cartModel->where("product_id", $_GET['id'])->where("customer_id", authUser()->customer_id)->first();
        if (!$cart) {
            $this->redirect("cart", [
                "message" => "Product not found in cart",
                "type" => "danger"
            ]);
        }
        $cartModel->delete($cart->cart_id);
        $this->redirect("cart", [
            "message" => "Product removed from cart",
            "type" => "success"
        ]);
    }

    public function addToWishlist()
    {
        if (!checkAuth()) {
            $this->redirect("login");
        }
        $product_id = $_GET['id'];
        $model = new Wishlist();
        $wishlist = $model->where("product_id", $product_id)->where("customer_id", authUser()->customer_id)->first();
        if ($wishlist) {
            $this->redirect("wishlist", [
                "message" => "Product already exists in wishlist",
                "type" => "danger"
            ]);
        }
        $wishlist = $model->create([
            "customer_id" => authUser()->customer_id,
            "product_id" => $product_id
        ]);
        $this->redirect("wishlist", [
            "message" => "Product added to wishlist",
            "type" => "success"
        ]);
    }

    public function wishlistToCart()
    {
        authUserMiddleware();
        $request = $_POST;
        $product_id = $request['product_id'];
        $quantity = $request['quantity'] ?? 1;
        $model = new Cart();
        $cart = $model->where("product_id", $product_id)->where("customer_id", authUser()->customer_id)->first();
        if ($cart) {
            $this->redirect("cart", [
                "message" => "Product already exists in cart",
                "type" => "danger"
            ]);
        }
        $model = new Cart();
        $model->create([
            "customer_id" => authUser()->customer_id,
            "product_id" => $product_id,
            "quantity" => $quantity
        ]);
        $model = new Wishlist();
        $model->delete($request['wishlist_id']);
        $this->redirect("cart", [
            "message" => "Product added to cart",
            "type" => "success"
        ]);
    }

    public function removeFromWishlist()
    {
        authUserMiddleware();
        if (!checkAuth()) {
            $this->redirect("login");
        }
        $model = new Wishlist();
        $wishlist = $model->where("product_id", $_GET['id'])->where("customer_id", authUser()->customer_id)->first();
        if (!$wishlist) {
            $this->redirect("wishlist", [
                "message" => "Product not found in wishlist",
                "type" => "danger"
            ]);
        }
        $model->delete($wishlist->wishlist_id);
        $this->redirect("wishlist", [
            "message" => "Product removed from wishlist",
            "type" => "success"
        ]);
    }


    public function cart()
    {
        authUserMiddleware();
        $model = new Cart();
        $items = $model->where("customer_id", authUser()->customer_id)->get();
        return $this->view("site.pages.cart", compact("items"));
    }

    public function wishlist()
    {
        authUserMiddleware();
        $model = new Wishlist();
        $items = $model->where("customer_id", authUser()->customer_id)->get();
        return $this->view("site.pages.wishlist", compact("items"));

    }

    public function checkout()
    {
        authUserMiddleware();
        $paymentModel = new Payment();
        $cartModel = new Cart();
        $orderModel = new Order();

        $cartItems = $cartModel->where("customer_id", authUser()->customer_id)->get();

        if (count($cartItems) == 0) {
            $this->redirect("cart", [
                "message" => "No items in cart",
                "type" => "danger"
            ]);
        }
        $order = $orderModel->create([
            "customer_id" => authUser()->customer_id,
            "order_date" => date("Y-m-d H:i:s"),
            "status" => "pending",
            "discount" => 0,
            "delivery" => 0,
            "total_price" => 0,
        ]);
        $totalPrice = 0;
        foreach ($cartItems as $cartItem) {
            $orderItemModel = new OrderItem();
            $orderItemModel->create([
                "order_id" => $order->order_id,
                "product_id" => $cartItem->product_id,
                "quantity" => $cartItem->quantity,
                "total_price" => $cartItem->total_price * $cartItem->quantity
            ]);

            $totalPrice += $cartItem->total_price * $cartItem->quantity;
            $cartModel->delete($cartItem->cart_id);
        }
        $paymentModel->create([
            "order_id" => $order->order_id,
            'customer_id' => authUser()->customer_id,
            "payment_date" => date("Y-m-d H:i:s"),
            "amount_paid" => $totalPrice,
            "card_number" => $_POST['card_number'],
            "exp_date" => $_POST['exp_date'],
            "cvv" => $_POST['cvv'],
        ]);
        $this->redirect("orders", [
            "message" => "Order placed successfully",
            "type" => "success"
        ]);
    }

    public function login()
    {
        return $this->view('site.pages.login');
    }

    public function register()
    {
        return $this->view('site.pages.register');
    }

    public function loginPost()
    {
        $request = $_POST;
        $model = new Customer();
        $customer = $model->where("email", $request['email'])->first();
        if ($customer) {
            if (password_verify($request['password'], $customer->password)) {
                $_SESSION['auth'] = [
                    "user" => $customer,
                    "role" => "customer"
                ];
                $this->redirect("orders");
            } else {
                $this->redirect("login", [
                    "message" => "Password is incorrect",
                    "type" => "danger"
                ]);
            }
        } else {
            $this->redirect("login", [
                "message" => "Email not found",
                "type" => "danger"
            ]);
        }
    }

    public function registerPost()
    {
        $request = $_POST;
        $model = new Customer();
        $customer = $model->where("email", $request['email'])->first();

        if ($customer) {
            return $this->redirect("register", [
                "message" => "Email already exists",
                "type" => "danger"
            ]);
        }
        $request['password'] = password_hash($request['password'], PASSWORD_DEFAULT);
        $customer = $model->create($request);
        $_SESSION['auth'] = [
            "user" => $customer,
            "role" => "customer"
        ];
        $this->redirect("orders");
    }

    public function logout()
    {
        unset($_SESSION['auth']);
        header("Location: " . url("login"));
    }

    public function orders()
    {
        authUserMiddleware();
        $model = new Order();
        $orders = $model->where("customer_id", authUser()->customer_id)->get();
        return $this->view("site.pages.orders", [
            "items" => $orders
        ]);
    }

    public function updateCart()
    {
        authUserMiddleware();
        $request = $_POST;
        $cart_id = $request['cart_id'];
        $product_id = $request['product_id'];
        $quantity = $request['quantity'] ?? 1;

        $model = new Cart();
        $cart = $model->where("cart_id", $cart_id)->where("customer_id", authUser()->customer_id)->first();
        if (!$cart) {
            return $this->redirect("cart", [
                "message" => "Product not found in cart",
                "type" => "danger"
            ]);
        }
        $model->update($cart_id, [
            "quantity" => $quantity
        ]);
        $this->redirect("cart", [
            "message" => "Product updated in cart",
            "type" => "success"
        ]);
    }

    public function resetPassword()
    {
        return $this->view("site.pages.reset-password");
    }

    public function resetPasswordPost()
    {
        $userModel = new Customer();
        $user = $userModel->where("email", $_POST['email'])->first();
        if (!$user) {
            return $this->redirect("reset-password", [
                "message" => "Email not found",
                "type" => "danger"
            ]);
        }
        $_SESSION['reset_user'] = $user;
        $code = rand(1000, 9999);
        $userModel = new Customer();
        $userModel->update($user->customer_id, [
            "reset_code" => $code
        ]);
        sendEmail($user, "Reset Code", "Reset Code is $code");
        return $this->view("site.pages.verify-reset");
    }

    public function verifyReset()
    {
        return $this->view("site.pages.verify-reset");

    }

    public function verifyResetPost()
    {
        $userModel = new Customer();
        $user = $userModel->where("customer_id", $_SESSION['reset_user']->customer_id)->first();
        if (!$user) {
            return $this->redirect("reset-password", [
                "message" => "Invalid request",
                "type" => "danger"
            ]);
        }
//        dd($user->reset_code,$_POST['code']);
        if ($user->reset_code != $_POST['code']) {
            return $this->redirect("reset-password", [
                "message" => "Code is incorrect",
                "type" => "danger"
            ]);
        }
        return $this->redirect("new-password");
    }


    public function testMail()
    {
        $userModel = new Customer();
        sendEmail($userModel->find(5), "Reset Code", "Reset Code is 1234");
    }

    public function newPassword()
    {
        return $this->view("site.pages.new-password");
    }

    public function newPasswordPost()
    {
        $request = $_POST;
        if ($request['password'] != $request['confirm_password']) {
            $this->redirect("new-password", [
                "message" => "Password and confirm password does not match",
                "type" => "danger"
            ]);
        }
        $userModel = new Customer();
        $user = $userModel->where("customer_id", $_SESSION['reset_user']->customer_id)->first();

        if (!$user) {
            $this->redirect("login", [
                "message" => "Invalid request",
                "type" => "danger"
            ]);
        }
        $userModel->update($user->customer_id, [
            "password" => password_hash($_POST['password'], PASSWORD_DEFAULT),
            "reset_code" => null
        ]);
        $this->redirect("login", [
            "message" => "Password changed successfully",
            "type" => "success"
        ]);

    }

    public function product()
    {
        $id = $_GET['id'];
        $model = new Product();
        $product = $model->find($id);
        return $this->view("site.pages.product", [
            "product" => $product
        ]);
    }

    public function feedback()
    {
        $model = new Product();
        $products = $model->all();
        return $this->view('site.pages.feedback', compact("products"));
    }

    public function feedbackPost()
    {
        $productModel = new Product();
        $product = $productModel->find($_POST['product_id']);
        if (!$product) {
            return $this->redirect("feedback", [
                "message" => "Product not found",
                "type" => "danger"
            ]);
        }
        $model = new Feedback();
        $model->create([
            "customer_id" => authUser()->customer_id,
            "product_id" => $_POST['product_id'],
            "title" => $_POST['title'],
            "feedback" => $_POST['feedback'],
        ]);
        return $this->redirect("feedback", [
            "message" => "Feedback added successfully",
            "type" => "success"
        ]);
    }

    public function profile()
    {
        authUserMiddleware();
        $model = new Customer();
        $user = $model->find(authUser()->customer_id);
        return $this->view("site.pages.profile", compact("user"));
    }

    public function profileSave(){
        authUserMiddleware();
        try {
            $request =$_POST;
            $model = new Customer();
            $model->update(authUser()->customer_id,$request);
            return $this->redirect("profile", [
                "message" => "Profile updated successfully",
                "type" => "success"
            ]);
        }catch (\Exception $exception){
            return $this->redirect("profile", [
                "message" => "Error in updating profile",
                "type" => "danger"
            ]);
        }
    }
}