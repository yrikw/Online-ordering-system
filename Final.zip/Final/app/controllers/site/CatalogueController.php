<?php
namespace app\controllers\site;
use app\models\Category;
use app\models\Page;
use app\models\Product;
use core\BaseController;

class  CatalogueController extends  BaseController
{
    public function home()
    {
        $productModel = new Product();
        $categoryModel = new Category();
        $category =[];
        $sql ="SELECT * FROM products WHERE 1=1";
        if (@$_GET['category']){
            $category = $categoryModel->find($_GET['category']);
            $sql .= " AND category_id=".$_GET['category'];
        }
        if(@$_GET['search']){
            $sql .= " AND name LIKE '%".$_GET['search']."%'";
        }
        $products = $productModel->rawQuery($sql)->fetchAll(\PDO::FETCH_OBJ);
        return $this->view("site.pages.catelogue",[
            "products"=>$products,
            "category"=>$category
        ]);
    }

}