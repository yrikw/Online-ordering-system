<?php
session_start();
// enable debug model
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

require_once __DIR__ . '/../system.php';