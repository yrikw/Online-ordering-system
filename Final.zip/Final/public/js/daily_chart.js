
  // Get canvas element and create the chart
  const salesChart = document.getElementById('dailyChart').getContext('2d');
  
  new Chart(salesChart, {
    type: 'pie',
    data: {
      labels: salesData.map((data) => data.label),
      datasets: [
        {
          data: salesData.map((data) => data.value),
          backgroundColor: ['rgba(54, 162, 235, 0.5)', 'rgba(255, 99, 132, 0.5)'],
          borderColor: ['rgba(54, 162, 235, 1)', 'rgba(255, 99, 132, 1)'],
          borderWidth: 1,
        },
      ],
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'bottom',
        },
      },
    },
  });
  