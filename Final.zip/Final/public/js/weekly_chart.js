 // Calculate retention rate
  const retentionData = salesData.map((data) => ({
    week: data.week,
    retentionRate: (data.customers / data.sales) * 100,
  }));
  
  // Get canvas element and create the chart
  const salesChart = document.getElementById('salesChart').getContext('2d');
  
  new Chart(salesChart, {
    type: 'line',
    data: {
      labels: retentionData.map((data) => `Week ${data.week}`),
      datasets: [
        {
          label: 'Order Rate',
          data: retentionData.map((data) => data.retentionRate),
          backgroundColor: 'rgba(54, 162, 235, 0.5)',
          borderColor: 'rgba(54, 162, 235, 1)',
          borderWidth: 2,
          pointRadius: 3,
          pointHoverRadius: 4,
        },
        {
          label: 'Number of Customers',
          data: salesData.map((data) => data.customers),
          backgroundColor: 'rgba(255, 99, 132, 0.5)',
          borderColor: 'rgba(255, 99, 132, 1)',
          borderWidth: 2,
          pointRadius: 3
        }
    ]
}
})  