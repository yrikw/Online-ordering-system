<!-- Navbar -->
<nav class="navbar fixed-top" style="background-color:#FCFBF6">
    <div class="container-fluid">
        <h1><a class="navbar-brand" href="<?= url('')?>" style="color: #562B08;;"><img src="<?= public_path('images/logo.png');?>" class="logo">Sarvello fine foods</a></h1>
        <ul class="nav me-auto mb-lg-0">
            <?php if (checkAuth()): ?>
            <li class="nav-item">
               <a class="nav-link" href="<?= url('cart')?>"><i class="bi bi-bag-check icon"></i></a>
            <li class="nav-item">
                <a class="nav-link" href="<?= url('wishlist')?>"><i class="bi bi-list-stars icon"></i></a>
            </li>
            <?php endif; ?>
            <li class="nav-item d-flex">
                <?php if (checkAuth()): ?>
                     <a class="nav-link" href="<?= url('profile')?>"><i class="bi bi-person-circle icon"></i></a>
                <?php else: ?>
                    <a class="nav-link text-black" href="<?= url('login')?>">
                        <i class="bi bi-key-fill"></i>
                    </a>
                    <a class="nav-link text-black" href="<?= url('register')?>">
                        <i class="bi bi-pencil-square"></i>
                    </a>
                <?php endif; ?>
            </li>
            <?php if (checkAuth()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?= url('logout')?>">
                        <i class="bi bi-box-arrow-right"></i>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
        <form class="d-flex" method="get" action="<?= url('catalogue') ?>">
            <input class="form-control me-2" type="search" name="search" placeholder="Search" aria-label="Search" value="<?= isset($_GET['search']) ? $_GET['search'] : '' ?>">
            <button class="btn btn-success" type="submit" style="padding: 0px 16px;">Search</button>
        </form>
    </div>

    <hr  style="grid-column: span 2; width: 100%;" />

    <!-- Offcampus -->
    <ul class="d-flex mt-2">
        <li class="mx-3">
            <a data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBackdrop" aria-controls="offcanvasWithBackdrop" style="cursor: pointer;"><i class="bi bi-list mx-2"></i>Browse products</a>
            <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasWithBackdrop" aria-labelledby="offcanvasWithBackdropLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasWithBackdropLabel">Browse products</h5>
                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                    <?php
                        $model = new app\models\Category();
                        $categories = $model->all();
                    ?>
                    <?php foreach ($categories as $category): ?>
                        <div class="d-flex">
                            <div class="flex-shrink-0 align-middle">
                                <img src="<?= public_path($category->images) ?>" alt="Sample Image" style="width: 100px; height: 100px;object-fit: cover">
                            </div>
                            <div class="flex-grow-1 ms-3 my-3">
                                <a href="<?= url('catalogue?category='.$category->category_id)?>"><p><?= $category->name?></p></a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </li>
        <li class="mx-3">
            <a  href="<?= url('catalogue') ?>">Catalogue</a>
        </li>
        <li class="mx-3">
            <a  href="<?= url('feedback') ?>">Feedback</a>
        </li>
        <li class="mx-3">
            <a  href="<?= url('page') ?>?id=1">About US</a>
        </li>
        <li class="mx-3">
            <a  href="<?= url('page') ?>?id=2">Contact Us</a>
        </li>
    </ul>
</nav>
