<div class="card my-2 border border-0">
    <img src="<?= public_path($product->image_pathlocation); ?>" class="card-img-top" style="height: 20rem; object-fit: cover;" alt="products">
    <div class="card-body">
        <h4>$<?= $product->price ?></h4>
        <p class="measurement"><small>$<?= $product->price ?> / EA</small></p>
        <a href="<?= url('product') ?>?id=<?= $product->product_id ?>">
            <h6 class="card-title my-4"><?= $product->name ?></h6>
        </a>
        <?php if($product->quantity > 0): ?>
            <p class="text-success">In stock</p>
        <?php else: ?>
            <p class="text-danger">Out of stock</p>
        <?php endif; ?>
        <?php if(checkCartExists($product->product_id)): ?>
            <a href="<?= url('removeFromCart')?>?id=<?= $product->product_id ?>" class="btn btn-danger mb-2" style="width: 100%">Remove from cart</a>
        <?php else: ?>
            <?php if(checkWishlistExists($product->product_id)): ?>
                <a href="<?= url('removeFromWishlist')?>?id=<?= $product->product_id ?>" class="btn my-2 list" style="width: 100%">Remove from list</a>
            <?php else: ?>
                <a href="<?= url('addToCart')?>?id=<?= $product->product_id ?>" class="btn btn-success mb-2" style="width: 100%">Add to cart</a>
                <a href="<?= url('addToWishlist')?>?id=<?= $product->product_id ?>" class="btn my-2 list" style="width: 100%">Save to Wishlist</a>
            <?php endif; ?>
        <?php endif; ?>


    </div>
</div>