<!-- Footer -->
<footer class="mt-5">
    <section>
        <div class="container">
            <div class="row row-cols-1 row-cols-sm-1 row-cols-md-3 row-cols-lg-3">
                <div class="col my-3">
                    <h5 class="my-3">Customer Services</h5>
                    <ul class="list-group list-group-flush">
                        <li class="border-0 my-2"><a href="<?= url('page') ?>?id=2">Contact Us</a></li>
                        <li class="border-0 my-2"><a href="<?= url('page') ?>?id=3">Return Policy</a></li>
                        <li class="border-0 my-2"><a href="<?= url('feedback') ?>">Feedback</a></li>
                    </ul>
                </div>
                <div class="col my-3">
                    <h5 class="my-3">Shop Groceries Online</h5>
                    <ul class="list-group list-group-flush">
                        <li class="border-0 my-2"><a href="<?= url('dashoard') ?>?id=1">View my account</a></li>
                        <li class="border-0 my-2"><a href="<?= url('orders') ?>">Pick up & Delivery</a></li>
                        <li class="border-0 my-2"><a href="<?= url('page') ?>?id=4">New to Online Shopping?</a></li>
                    </ul>
                </div>
                <div class="col my-3">
                    <h5 class="my-3">Customer Services</h5>
                    <ul class="list-group list-group-flush">
                        <li class="border-0 my-2"><a href="<?= url('page') ?>?id=5">Why pick us?</a></li>
                        <li class="border-0 my-2"><a href="<?= url('suppliers') ?>">Suppliers</a></li>
                        <li class="border-0 my-2"><a href="<?= url('page') ?>?id=6">Careers</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="my-3 w-50" style="margin: 0 auto; text-align: center;">
        <!-- Facebook -->
        <a
                class="btn btn-link btn-floating btn-lg m-1"
                href="#!"
                role="button"
        ><i class="bi bi-facebook icon"></i></i
            ></a>

        <!-- Twitter -->
        <a
                class="btn btn-link btn-floating btn-lg text-dark m-1"
                href="#!"
                role="button"
        ><i class="bi bi-twitter icon"></i
            ></a>

        <!-- Instagram -->
        <a
                class="btn btn-link btn-floating btn-lg text-dark m-1"
                href="#!"
                role="button"
        ><i class="bi bi-instagram icon"></i
            ></a>
    </section>

    <section>
        <div class="text-center p-2">
            Sarvello fine foods © 2023 Copyright
        </div>
    </section>
</footer>
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
</body>
</html>
