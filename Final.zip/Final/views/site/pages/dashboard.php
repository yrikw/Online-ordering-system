<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
    <main class="min-height:80vh;">
        <section class="my-5 w-50" style="margin: 0 auto; text-align: center;">
            <h3>Dashboard</h3>
            <hr class="my-3">
        </section>
        <div class="container">

        </div>
    </main>
<?php component('site.inc.footer'); ?>