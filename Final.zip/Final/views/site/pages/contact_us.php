<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
<main>

</main>
<?php component('site.inc.footer'); ?>

