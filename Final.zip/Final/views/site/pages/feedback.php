<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
    <main class="min-height:80vh;">
        <section class="my-5 w-50" style="margin: 0 auto; text-align: center;">
            <h3>Feedback</h3>
            <hr class="my-3">
        </section>
        <div class="container">
            <div class="row">
                <section class="col-8 col-md-8 col-lg-6" style="margin: 0 auto;">
                    <div class="p-4">
                        <?= form_status() ?>
                    </div>
                    <form class="mb-3" method="post" action="<?= url('feedback')?>">
<!--                        projects-->
                        <div class="mb-3">
                            <label for="" class="form-label">
                                Project
                            </label>
                            <select name="product_id" class="form-control" id="" required>
                                <option value="">Select Product</option>
                                <?php foreach ($products as $project): ?>
                                    <option value="<?= $project->product_id ?>"><?= $project->name ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">
                                Title
                            </label>
                            <input type="text" name="title" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"  required>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">
                                Feedback
                            </label>
                            <textarea name="feedback" class="form-control" id="exampleInputPassword1"  required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Send Feed</button>
                    </form>
                </section>
            </div>
        </div>
    </main>
<?php component('site.inc.footer'); ?>