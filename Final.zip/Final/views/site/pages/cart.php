<?php
$total = 0;
?>
<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
<main class="min-height:80vh;">
    <section class="my-5 w-50" style="margin: 0 auto; text-align: center;">
        <h3>Cart</h3>
        <hr class="my-3">
    </section>
    <div class="container">
        <div class="p-4">
            <?= form_status() ?>
        </div>
        <?php foreach ($items as $item) : ?>
            <?php
            $model = new \app\models\Product();
            $product = $model->find($item->product_id);
            $total += $product->price * $item->quantity;
            ?>
            <form class="row row-cols-1 row-cols-sm-2 row-cols-md-3 col-lg-9 d-flex align-items-center justify-content-center" method="post">
                <!-- Product 1 -->
                <div class="col-md-2">
                    <img src="<?= public_path($product->image_pathlocation) ?>" class="card-img-top" alt="products">
                </div>
                <div class="col-md-3">
                    <h6 class="card-title"><?= $product->name ?></h6>
                    <p class="card-text">Price: $<?= $product->price ?></p>
                </div>
                <div class="col-md-3">
                    <div class="input-group">
                        <input type="hidden" name="cart_id" value="<?= $item->cart_id; ?>">
                        <input type="hidden" name="product_id" value="<?= $product->product_id; ?>">
                        <input type="number" class="form-control product-quantity" name="quantity" value="<?= @$item->quantity ?? 1; ?>" min="1" max="50" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="btn-group" role="group">
                        <button type="submit" class="btn btn-outline-secondary save-to-wishlist add-to-cart-from-wishlist" style="margin: 0;">Update</button>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-outline-secondary save-to-wishlist delete-from-cart" data-cart-id="<?= $item->cart_id ?>" data-product-id="<?= $product->product_id ?>">Delete</button>
                    </div>
                </div>
            </form>
        <?php endforeach; ?>
        <div class="d-flex justify-content-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 offset-md-2"> <!-- Increase the width of the column -->
                        <div class="container payment-container p-4 mb-4" style="background-color: #f5f5f5; border-radius: 10px;"> <!-- Add background color and border radius -->
                            <form method="post" action="<?= url('checkout') ?>">
                                <fieldset>
                                    <div id="legend">
                                        <legend class="">Payment</legend>
                                    </div>
                                    <div class="control-group">
                                        <label class="control-label" for="total">Total</label>
                                        <div class="controls">
                                            $<?= $total ?> /-
                                        </div>
                                    </div>

                                    <div class="control-group">
                                        <label class="control-label" for="username">Card Holder's Name</label>
                                        <div class="controls">
                                            <input type="text" id="username" name="username" placeholder="" value="<?= authUser()->first_name ?> <?= authUser()->family_name ?>" class="input-xlarge" required>
                                        </div>
                                    </div>

                                    <div class="control-group">
                                        <label class="control-label" for="card_number">Card Number</label>
                                        <div class="controls">
                                            <input type="text" id="card_number" name="card_number" placeholder="" class="input-xlarge" required>
                                        </div>
                                    </div>

                                    <div class="control-group">
                                        <label class="control-label" for="exp_date">Card Expiry Date</label>
                                        <div class="controls">
                                            <input type="text" name="exp_date" placeholder="MM/YY" class="input-xlarge" required>
                                        </div>
                                    </div>

                                    <div class="control-group">
                                        <label class="control-label" for="password_confirm">CVV</label>
                                        <div class="controls">
                                            <input type="password" id="password_confirm" name="cvv" placeholder="" class="span2" required>
                                        </div>
                                    </div>

                                    <div class="control-group">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label class="control-label" for="pickup_date">Pick-up Date</label>
                                                <div class="controls">
                                                    <input type="date" id="pickup_date" name="pickup_date" class="input-xlarge" required>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="control-label" for="pickup_time">Pick-up Time</label>
                                                <div class="controls">
                                                    <input type="time" id="pickup_time" name="pickup_time" class="input-xlarge" required>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <br>

                                    <div class="control-group">
                                        <div class="controls text-center">
                                            <button class="btn btn-success btn-lg">Checkout</button>
                                        </div>
                                    </div>

                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php component('site.inc.footer'); ?>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const deleteButtons = document.querySelectorAll(".delete-from-cart");

        deleteButtons.forEach(function(button) {
            button.addEventListener("click", function() {
                // Get the cart ID and product ID from data attributes
                const cartId = button.dataset.cartId;
                const productId = button.dataset.productId;

                // Send an AJAX request to remove the product from the cart
                const xhr = new XMLHttpRequest();
                xhr.open("GET", `<?= url('removeFromCart') ?>?cart_id=${cartId}&product_id=${productId}`, true);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            // Remove the product form the DOM
                            const form = button.closest("form");
                            if (form) {
                                form.remove();
                            }
                        } else {
                            console.error("Error removing product from cart.");
                        }
                    }
                };
                xhr.send();
            });
        });
    });
</script>
