<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
    <main class="min-height:80vh;">
        <section class="my-5 w-50" style="margin: 0 auto; text-align: center;">
            <h3>Orders</h3>
            <hr class="my-3">
        </section>
        <div class="container">
            <div class=p-4>
                <?= form_status() ?>
            </div>
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 col-lg-9 d-flex align-items-center justify-content-center fw-bold" >
                <!-- Product 1 -->
                <div class="col-md-2">
                    #ID
                </div>
                <div class="col-md-5">
                    <div>
                       Products
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="btn-group" role="group">
                       Status
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="btn-group" role="group">
                        Total
                    </div>
                </div>
            </div>
            <?php
              $total =0;
              ?>
            <?php foreach ($items as $item):?>
                <?php
                $model =new \app\models\OrderItem();
                $productModel = new \app\models\Product();
                $orderTtems = $model->where('order_id', $item->order_id)->get();

                ?>
                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 col-lg-9 d-flex align-items-center justify-content-center" >
                    <!-- Product 1 -->
                    <div class="col-md-2">
                        <?= $item->order_id ?>
                    </div>
                    <div class="col-md-5">
                        <div>
                        <?php foreach ($orderTtems as $ot): ?>
                            <?php
                               $p = $productModel->find($ot->product_id);
                                $total += $p->price*$ot->quantity;
                            ?>

                            <?= $p->name ?>,

                        <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="btn-group" role="group">
                             <?= $item->status ?>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="btn-group" role="group">
                            <?= $total ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

        </div>
    </main>
<?php component('site.inc.footer'); ?>