<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
<main class="min-height:80vh;">
    <?php if(!$page): ?>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Page not found</h1>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if($page): ?>
            <section class="mt-5 mx-5">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= url('/')?>" class="text-success">Home</a></li>
                        <li class="breadcrumb-item"><?= $page->slug; ?></li>
                    </ol>
                </nav>
                <h3><?= $page->title; ?></h3>
                <hr>
            </section>
            <section class="container">
                <div class="row d-flex justify-content-center ">
                    <div class="mb-3 col-10 col-sm-12 col-md-12 col-lg-12">
                         <?=  $page->content; ?>
                    </div>
                </div>
            </section>
    <?php endif; ?>
</main>
<?php component('site.inc.footer'); ?>