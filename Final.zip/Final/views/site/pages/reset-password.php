<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
    <main class="min-height:80vh;">
        <section class="my-5 w-50" style="margin: 0 auto; text-align: center;">
            <h3>Reset Password</h3>
            <hr class="my-3">
        </section>
        <div class="container">
            <div class="row">
                <section class="col-8 col-md-8 col-lg-6" style="margin: 0 auto;">
                    <div class="p-4">
                        <?= form_status() ?>
                    </div>
                    <form class="mb-3" method="post">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Email address</label>
                            <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"  required>
                        </div>
                        <button type="submit" class="btn btn-primary">Reset</button>
                    </form>
                </section>
            </div>
        </div>
    </main>
<?php component('site.inc.footer'); ?>