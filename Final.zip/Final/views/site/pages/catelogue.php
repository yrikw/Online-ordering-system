<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
<main class="min-height:80vh;">
    <section class="mt-5 mx-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= url('/')?>" class="text-success">Home</a></li>
                <li class="breadcrumb-item">
                    <!--                            --><?php // $category->title ?>
                </li>
            </ol>
        </nav>
        <h3><?= @$category->name; ?></h3>
        <hr>
    </section>
    <section class="cards">
        <div class="container">
            <div class="row row-cols-2 row-cols-sm-2 row-cols-md-4 row-cols-lg-5 justify-content-center">
                <?php foreach ($products as $product): ?>
                    <div class="col-md-4">
                        <div class="product-image" style="background-image: url('<?= $product->image ?>');"></div>
                        <?php component('site.inc.product',[
                            'product' => $product
                        ]); ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
</main>
<?php component('site.inc.footer'); ?>

<style>
.product-image {
    width: 100%;
    height: 0;
    padding-bottom: 100%;
    background-size: cover;
    background-position: center;
}
</style>
