<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
<main>
    <!-- Carousel -->
    <div id="carouselExampleDark" class="carousel slide mb-3" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="<?= public_path('images/top1.jpg');?>" class="d-block w-100" alt="..." style="max-height: 350px; object-fit:cover;">
            </div>
            <div class="carousel-item">
                <img src="<?= public_path('images/top2.jpg');?>" class="d-block w-100" alt="..." style="max-height: 350px; object-fit:cover;">
            </div>
            <div class="carousel-item">
                <img src="<?= public_path('images/top3.jpg');?>" class="d-block w-100" alt="..." style="max-height: 350px; object-fit:cover;">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <!-- Title -->
    <section class="my-5 w-50" style="margin: 0 auto; text-align: center;">
        <h3>Welcome to Sarvello fine foods</h3>
        <hr class="my-3"/>
        <h5>Feature products</h5>
    </section>

    <!-- Products cards -->
    <section class="cards">
        <div class="container">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-5">
                <?php foreach ($products as  $product): ?>
                    <?php component('site.inc.product', ['product' => $product]) ?>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Subscrption -->
    <section class="subscribe mt-5">
        <img src="<?= public_path('images/bg-1.png');?>" alt="background" style="width: 100%; height: 200px;object-fit: cover;">
        <div class="center">
            <p style="color: white;">GET INSTANT DEALS AND EXCLUSIVE OFFER!</p>
            <form class="d-flex">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="E-mail">
                <button class="btn btn-success" type="submit" style="padding: 0px 16px;">Subscribe</button>
            </form>
        </div>
    </section>
</main>
<?php component('site.inc.footer'); ?>
