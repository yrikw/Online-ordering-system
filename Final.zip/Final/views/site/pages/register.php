<?php
 $jobtypes = new  \app\models\JobType();
?>
<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
    <main class="min-height:80vh;">
        <section class="my-5 w-50" style="margin: 0 auto; text-align: center;">
            <h3>Customer Registration</h3>
            <hr class="my-3">
        </section>
        <section class="col-8 col-md-8 col-lg-6" style="margin: 0 auto;">
            <p>Already have an account?<a href="<?= url('login') ?>" class="text-success ms-3">Login Here</a></p>
            <div class="p-4">
                <?= form_status() ?>
            </div>
            <form class="mb-3"  method="post">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                    <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" id="exampleInputPassword1"  required>
                    <div id="passwordHelpBlock" class="form-text">
                        Your password must be 8-20 characters long, contain letters and numbers, and must not contain spaces, special characters, or emoji.
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label m-1">First Name</label>
                    <input type="text" name="first_name" class="form-control"  required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Last Name</label>
                    <input type="text" name="family_name"  class="form-control"  required>
                </div>

                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Date of Birth</label>
                    <input type="date" name="date_of_birth" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"  required>
                </div>
                <div class="mb-3 col-sm-12 col-md-4 col-lg-4">
                    <label class="form-label">Job Type</label>
                    <select  name="job_type_id"  class="form-control" required>
                        <option value="">Select Job Type</option>
                        <?php foreach ($jobtypes->all() as $jobtype): ?>
                            <option value="<?= $jobtype->job_type_id ?>"><?= $jobtype->name ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3 text-center">
                    <button class="btn btn-success " type="submit">Register</button>
                </div>
            </form>
        </section>
    </main>
<?php component('site.inc.footer'); ?>