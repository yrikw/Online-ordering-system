<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
<main class="min-height:80vh">
    <?php if(!$product): ?>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Page not found</h1>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if($product): ?>
        <section class="mt-5 mx-5">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= url('/')?>" class="text-success">Home</a></li>
                    <li class="breadcrumb-item"><?= $product->name; ?></li>
                </ol>
            </nav>
            <div class="container-lg"> <!-- Increased container size using 'container-lg' class -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow">
                            <div class="card-body">
                                <div class="row">
                                    <!-- Image -->
                                    <div class="col-md-6">
                                        <div class="image-wrapper">
                                            <img src="<?= public_path($product->image_pathlocation); ?>" alt="<?= $product->name; ?>" class="img-fluid square-image">
                                        </div>
                                    </div>
                                    <!-- Details -->
                                    <div class="col-md-6">
                                        <div class="details-wrapper">
                                            <h3 class="mt-0"><?= $product->name; ?></h3>
                                            <hr>
                                            <div class="mb-3">
                                                <?= $product->description; ?>
                                            </div>
                                            <div class="mb-3">
                                                <h4>Price: <?= $product->price; ?></h4>
                                            </div>
                                            <div>
                                                <?php if(checkCartExists($product->product_id)): ?>
                                                    <a href="<?= url('removeFromCart')?>?id=<?= $product->product_id ?>" class="btn btn-danger mb-2" style="width: 100%">Remove from cart</a>
                                                <?php else: ?>
                                                    <?php if(checkWishlistExists($product->product_id)): ?>
                                                        <a href="<?= url('removeFromWishlist')?>?id=<?= $product->product_id ?>" class="btn my-2 list" style="width: 100%">Remove from list</a>
                                                    <?php else: ?>
                                                        <a href="<?= url('addToCart')?>?id=<?= $product->product_id ?>" class="btn btn-success mb-2" style="width: 100%">Add to cart</a>
                                                        <a href="<?= url('addToWishlist')?>?id=<?= $product->product_id ?>" class="btn my-2 list" style="width: 100%">Save to Wishlist</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
</main>
<?php component('site.inc.footer'); ?>

<style>
   /* Custom CSS for the modified code */
.card {
  border-radius: 5px;
  border: 1px solid #ccc;
  transition: box-shadow 0.3s ease;
}

.card:hover {
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
}

.image-wrapper {
  text-align: center;
}

.square-image {
  width: 100%;
  height: auto;
  max-width: 400px;
  aspect-ratio: 1/1; /* Set the aspect ratio to make the image more square */
}

.details-wrapper {
  padding: 20px;
}

.list {
  margin-right: 10px;
}

/* Decrease gap between image and details */
@media (min-width: 768px) {
  .row .col-md-6 {
    padding-right: 10px;
    padding-left: 10px;
  }
}
</style>
