<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
    <main class="min-height:80vh;">
        <section class="my-5 w-50" style="margin: 0 auto; text-align: center;">
            <h3>Login</h3>
            <hr class="my-3">
        </section>
        <div class="container">
            <div class="row">
                <section class="col-8 col-md-8 col-lg-6" style="margin: 0 auto;">
                    <div class="p-4">
                        <?= form_status() ?>
                    </div>
                    <form class="mb-3" method="post">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Email address</label>
                            <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"  required>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" id="exampleInputPassword1"  required>
                            <div id="passwordHelpBlock" class="form-text">
                                Your password must be 8-20 characters long, contain letters and numbers, and must not contain spaces, special characters, or emoji.
                            </div>
                        </div>
                        <a href="<?= url('reset-password') ?>" class="text-success">Forgot your password?</a>
                        <div class="my-3 form-check">
                            <input type="checkbox" class="form-check-input" id="exampleCheck1">
                            <label class="form-check-label" for="exampleCheck1">Remember Me</label>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                    <p>New to Sarvello Fine Foods?<a href="<?= url('register') ?>" class="text-success ms-3">Register Here</a></p>
                </section>
            </div>
        </div>
    </main>
<?php component('site.inc.footer'); ?>