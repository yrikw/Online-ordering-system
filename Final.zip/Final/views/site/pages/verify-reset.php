<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
    <main class="min-height:80vh;">
        <section class="my-5 w-50" style="margin: 0 auto; text-align: center;">
            <h3>Verify Reset</h3>
            <hr class="my-3">
        </section>
        <div class="container">
            <div class="row">
                <section class="col-8 col-md-8 col-lg-6" style="margin: 0 auto;">
                    <div class="p-4">
                        <?= form_status() ?>
                    </div>
                    <form class="mb-3" method="post" action="<?= url('verify-reset') ?>"
                        <div class="mb-3">
                            <label  class="form-label">Verification Code</label>
                            <input type="text" name="code" class="form-control"  required>
                        </div>
                       <div>
                           <button type="submit" class="btn btn-primary">Reset</button>
                       </div>
                    </form>
                </section>
            </div>
        </div>
    </main>
<?php component('site.inc.footer'); ?>