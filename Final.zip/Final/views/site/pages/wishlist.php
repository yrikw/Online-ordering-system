<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
    <main class="min-height:80vh;">
        <section class="my-5 w-50" style="margin: 0 auto; text-align: center;">
            <h3>Wishlist</h3>
            <hr class="my-3">
        </section>
        <div class="container">
            <div class="p-4">
                <?= form_status() ?>
            </div>
            <?php foreach ($items as $item): ?>
                <?php
                $model = new \app\models\Product();
                $product = $model->find($item->product_id);
                ?>
                <form class="row row-cols-1 row-cols-sm-2 row-cols-md-3 col-lg-9 d-flex align-items-center justify-content-center" method="post">
                    <!-- Product 1 -->
                    <div class="col-md-2">
                        <img src="<?= public_path($product->image_pathlocation) ?>" class="card-img-top" alt="products">
                    </div>
                    <div class="col-md-3">
                        <h6 class="card-title"><?= $product->name ?></h6>
                        <p class="card-text">Price: $<?= $product->price ?></p>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group">
                            <input type="hidden" name="product_id" value="<?= $product->product_id; ?>">
                            <input type="number" class="form-control product-quantity" name="quantity" value="<?= @$item->quantity ?? 1; ?>" min="1" max="50" required>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="btn-group" role="group">
                            <button type="submit" class="btn btn-outline-secondary save-to-wishlist add-to-cart-from-wishlist" style="margin: 0;">Add to Cart</button>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-outline-secondary save-to-wishlist delete-from-wishlist" data-product-id="<?= $product->product_id ?>">Delete</button>
                        </div>
                    </div>
                </form>
            <?php endforeach; ?>
        </div>
    </main>
<?php component('site.inc.footer'); ?>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const deleteButtons = document.querySelectorAll(".delete-from-wishlist");

        deleteButtons.forEach(function(button) {
            button.addEventListener("click", function() {
                // Get the product ID from the data attribute
                const productId = button.dataset.productId;

                // Send an AJAX request to remove the product from the wishlist
                const xhr = new XMLHttpRequest();
                xhr.open("GET", `<?= url('removeFromWishlist') ?>?id=${productId}`, true);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            // Remove the product form the DOM
                            const form = button.closest("form");
                            if (form) {
                                form.remove();
                            }
                        } else {
                            console.error("Error removing product from wishlist.");
                        }
                    }
                };
                xhr.send();
            });
        });
    });
</script>
