<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
<main class="min-height:80vh">
  <section class="my-5 text-center">
    <h3>Profile</h3>
    <hr class="my-3">
  </section>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 col-md-8 col-lg-6">
        <section class="bg-white shadow p-4">
          <?= form_status() ?>
          <form class="mb-3" method="post">
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">First Name</label>
              <input type="text" name="first_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?= $user->first_name ?>" required>
            </div>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Family Name</label>
              <input type="text" name="family_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?= $user->family_name ?>" required>
            </div>
            <div class="mb-3">
              <label for="phone_no">Phone No</label>
              <input type="text" name="phone_no" class="form-control" id="phone_no" value="<?= $user->phone_no ?>" required>
            </div>
            <div class="mb-3">
              <label for="email">Email</label>
              <input type="email" name="email" class="form-control" id="email" value="<?= $user->email ?>" required>
            </div>
            <div class="mb-3">
              <label for="address">Address</label>
              <textarea name="address" class="form-control" id="address" required><?= $user->address ?></textarea>
            </div>
            <div class="mb-3">
              <label for="date_of_birth">Date of Birth</label>
              <input type="date" name="date_of_birth" class="form-control" id="date_of_birth" value="<?= $user->date_of_birth ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </section>
      </div>
    </div>
  </div>
</main>
<?php component('site.inc.footer'); ?>
