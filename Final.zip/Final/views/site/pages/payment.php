<?php component('site.inc.header'); ?>
<?php component('site.inc.navbar'); ?>
    <main class="min-height:80vh;">
        <section class="my-5 w-50" style="margin: 0 auto; text-align: center;">
            <h3>Checkout</h3>
            <hr class="my-3">
        </section>
        <div class="container">
            <div class=p-4>
                <?= form_status() ?>
            </div>
            <div class="row">
                <?php foreach ($items as $item):?>
                <div class="col-md-8">
                    <?php
                        $model =new \app\models\Product();
                        $product = $model->find($item->product_id);
                    ?>
                    <form class="row row-cols-1 row-cols-sm-2 row-cols-md-3 col-lg-9 d-flex align-items-center justify-content-center" method="post">
                        <!-- Product 1 -->
                        <div class="col-md-2">
                            <img src="<?= public_path( $product->image_pathlocation)?>" class="card-img-top" alt="products">
                        </div>
                        <div class="col-md-3">
                            <h6 class="card-title"><?= $product->name ?></h6>
                            <p class="card-text">Price: $<?= $product->price ?></p>
                        </div>
                        <div class="col-md-3">
                            <div class="input-group">
                                <input type="hidden" name="cart_id" value="<?= $item->cart_id; ?>">
                                <input type="hidden" name="product_id" value="<?= $product->product_id; ?>">
                                <input type="number" class="form-control product-quantity" name="quantity" value="<?= @$item->quantity??1; ?>" min="1" max="50" required>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="btn-group" role="group">
                                <button type="submit" class="btn btn-outline-secondary save-to-wishlist add-to-cart-from-wishlist" style="margin: 0;">Update</button>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="btn-group" role="group">
                                <a href="<?= url('removeFromCart')?>?id<?= $product->id ?>" type="button" class="btn btn-outline-secondary save-to-wishlist delete-from-wishlist" data-product="Juicy Orange">Delete</a>
                            </div>
                        </div>
                    </form>
                </div>
                <?php endforeach;  ?>
                <div class="cal-md-9">
                    <div class="card">
                        <div class="card-header">
                            <h5>Order Summary</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">Subtotal</div>
                                <div class="col-md-6">$<?= $subtotal ?></div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">Tax</div>
                                <div class="col-md-6">$<?= $tax ?></div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">Shipping</div>
                                <div class="col-md-6">$<?= $shipping ?></div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">Total</div>
                                <div class="col-md-6">$<?= $total ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php foreach ($items as $item):?>
                <?php
                $model =new \app\models\Product();
                $product = $model->find($item->product_id);
                ?>
                <form class="row row-cols-1 row-cols-sm-2 row-cols-md-3 col-lg-9 d-flex align-items-center justify-content-center" method="post">
                    <!-- Product 1 -->
                    <div class="col-md-2">
                        <img src="<?= public_path( $product->image_pathlocation)?>" class="card-img-top" alt="products">
                    </div>
                    <div class="col-md-3">
                        <h6 class="card-title"><?= $product->name ?></h6>
                        <p class="card-text">Price: $<?= $product->price ?></p>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group">
                            <input type="hidden" name="cart_id" value="<?= $item->cart_id; ?>">
                            <input type="hidden" name="product_id" value="<?= $product->product_id; ?>">
                            <input type="number" class="form-control product-quantity" name="quantity" value="<?= @$item->quantity??1; ?>" min="1" max="50" required>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="btn-group" role="group">
                            <button type="submit" class="btn btn-outline-secondary save-to-wishlist add-to-cart-from-wishlist" style="margin: 0;">Update</button>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="btn-group" role="group">
                            <a href="<?= url('removeFromCart')?>?id<?= $product->id ?>" type="button" class="btn btn-outline-secondary save-to-wishlist delete-from-wishlist" data-product="Juicy Orange">Delete</a>
                        </div>
                    </div>
                </form>
            <?php endforeach; ?>
            <div class="d-flex justify-content-center">
                <a href="<?= url('checkout')?>" class="btn btn-primary">Checkout</a>
            </div>
        </div>
    </main>
<?php component('site.inc.footer'); ?>