<?php
//remove last character from string
  $pageTitle = $entity->table;
  $link = strtolower($pageTitle);
  $entity->setReturnTypeArr();
  $all = $entity->all();
  $tableData = $entity->process($all,$tableColumns);
?>
<div class="main-panel">
    <main>
        <div class="content-wrapper">
            <div class="row">
                <div class="col-md-12 grid-margin">
                    <div class="d-flex justify-content-between flex-wrap">
                        <div class="d-flex align-items-end flex-wrap">
                            <div class="me-md-3 me-xl-5">
                                <h2>Welcome back,</h2>
                                <p class="mb-md-0">
                                    <?= authUser()->family_name;?>
                                </p>
                            </div>
                            <div class="d-flex">
                                <i class="mdi mdi-home text-muted hover-cursor"></i>

                                <p class="text-muted mb-0">
                                    <?php foreach ($breadcumbs as $breadcumb): ?>
                                        &nbsp;/&nbsp;<?=  $breadcumb?>
                                    <?php endforeach; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 ">
                    <div class="d-flex justify-content-between flex-wrap" style="width: 100%;">
                        <div class="d-flex align-items-end flex-wrap" style="overflow-x:auto;width: 100%;">
                            <div class="row" style="width: 100%;">
                                <div class="col-md-12 stretch-card" style="width: 100%;">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="d-flex w-100  justify-content-between">
                                                <p class="card-title"><?=  $pageTitle ?> List</p>
                                                <?php if(in_array('add', $tableActions)): ?>
                                                    <a href="<?= url("admin/$link/save") ?>" class="btn btn-primary" style="color: white; text-decoration: none;">
                                                        Add
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                            <div class="d-flex justify-content-center p-2">
                                                <?= form_status() ?>
                                            </div>
                                            <div class="table-responsive" style="height: 50vh;overflow-y: scroll">
                                                <table id="recent-purchases-listing" class="table">
                                                    <thead>
                                                    <tr>
                                                        <?php foreach ($tableColumns as $th): ?>
                                                            <th>
                                                                <?=  $th['label'] ?>
                                                            </th>
                                                        <?php endforeach; ?>
                                                        <?php if ($tableActions): ?>
                                                            <th>Actions</th>
                                                        <?php endif; ?>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php if(!$tableData): ?>
                                                            <tr>
                                                                <td colspan="<?= count($tableColumns) + 1 ?>" style="text-align: center">No data found</td>
                                                            </tr>
                                                        <?php else: ?>
                                                            <?php foreach ($tableData as $key=>$data): ?>
                                                                <tr>
                                                                    <?php foreach ($tableColumns as $th): ?>
                                                                        <td>
                                                                            <?php if(@$th['type']=='image'): ?>
                                                                                <img src="<?=  public_path($data[$th['field']]) ?>" alt="" style="width: 100px; height: 100px;">
                                                                            <?php else: ?>
                                                                                <?php if(is_callable(@$th['render'])): ?>
                                                                                    <?= $th['render']($data[$th['field']],$data) ?>
                                                                                <?php else: ?>
                                                                                    <?=   $data[$th['field']] ?>
                                                                                <?php endif ?>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    <?php endforeach; ?>
                                                                    <td>
                                                                    <?php if(in_array('edit', $tableActions)): ?>
                                                                       <a class="btn btn-primary" href="<?= url("admin/$link/save?id=".$data[$entity->getIdAttribute()])?>" style="color: white; text-decoration: none;">Edit</a>
                                                                    <?php endif; ?>
                                                                    <?php if(in_array('delete', $tableActions)): ?>
                                                                        <a class="btn btn-secondary" href="<?= url("admin/$link/delete?id=".$all[$key][$entity->getIdAttribute()])?>" style="color: white;  text-decoration: none;">Delete</a>
                                                                    <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; ?>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- cotent-wrapper ends -->
    <!-- partial:partials/_footer.html -->
    <footer class="footer">
        <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <a href="https://www.bootstrapdash.com/" target="_blank">Sarvello fine foods </a>2023</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Only the best <a href="https://www.bootstrapdash.com/" target="_blank"> Bootstrap dashboard  </a> templates</span>
        </div>
    </footer>
    <!-- partial -->
</div>