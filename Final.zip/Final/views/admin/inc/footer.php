
<!-- plugins:js -->
<script src="<?= public_path('admin_assets/vendors/base/vendor.bundle.base.js') ?>"></script>
<!-- endinject -->
<!-- Plugin js for this page-->
<script src="<?= public_path('admin_assets/vendors/chart.js/Chart.min.js') ?>"></script>
<script src="<?= public_path('admin_assets/vendors/datatables.net/jquery.dataTables.js') ?>"></script>
<script src="<?= public_path('admin_assets/vendors/datatables.net-bs4/dataTables.bootstrap4.js') ?>"></script>
<!-- End plugin js for this page-->
<!-- inject:js -->
<script src="<?= public_path('admin_assets/js/off-canvas.js') ?>"></script>
<script src="<?= public_path('admin_assets/js/hoverable-collapse.js') ?>"></script>
<script src="<?= public_path('admin_assets/js/template.js') ?>"></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src="<?= public_path('admin_assets/js/dashboard.js') ?>"></script>
<script src="<?= public_path('admin_assets/js/data-table.js') ?>"></script>
<script src="<?= public_path('admin_assets/js/jquery.dataTables.js') ?>"></script>
<script src="<?= public_path('admin_assets/js/dataTables.bootstrap4.js') ?>"></script>
<!-- End custom js for this page-->

<script src="<?= public_path('js/jquery.cookie.js') ?>" type="text/javascript"></script>
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<script>
    const editor= document.querySelector('#editor');
    var quill = new Quill('#editor', {
        theme: 'snow',
    });
    quill.on('text-change', function() {
        const input = document.getElementById(`editor_${editor.getAttribute('input-name')}`);
        input.value = quill.root.innerHTML;
    });
</script>
</body>
</html>

