<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sarvello Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="<?= public_path('admin_assets/vendors/mdi/css/materialdesignicons.min.css') ?>">
    <link rel="stylesheet" href="<?= public_path('admin_assets/vendors/base/vendor.bundle.base.css') ?>">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <link rel="stylesheet" href="<?= public_path('admin_assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css') ?>">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="<?= public_path('admin_assets/css/style.css') ?>">
    <!-- endinject -->
    <link rel="shortcut icon" href="<?= public_path('admin_assets/images/favicon.png') ?>" />
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <script
            src="https://code.jquery.com/jquery-3.7.0.min.js"
            integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g="
            crossorigin="anonymous"></script>
    <style>
        select.form-control, .dataTables_wrapper select {
            color: #000 !important;
        }
    </style>
</head>
<body>
