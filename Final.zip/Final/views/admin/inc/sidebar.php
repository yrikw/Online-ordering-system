<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="<?= url('admin/dashboard') ?>">
                <i class="mdi mdi-home menu-icon"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
                <!-- <i class="mdi mdi-circle-outline menu-icon"></i> -->
                <i class="mdi mdi-file-document-box-outline menu-icon"></i>
                <span class="menu-title">Reports</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="<?= url('admin/daily-report'); ?>">Daily report</a></li>
                    <li class="nav-item"> <a class="nav-link" href="<?= url('admin/weekly-report'); ?>">Weekly report</a></li>
                    <li class="nav-item"> <a class="nav-link" href="<?= url('admin/monthly-report'); ?>">Monthly report</a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= url('admin/products') ?>">
                <i class="mdi mdi-basket menu-icon"></i>
                <span class="menu-title">Products</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= url('admin/staff') ?>">
                <i class="mdi mdi-account-multiple menu-icon"></i>
                <span class="menu-title">Staffs</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= url('admin/customer') ?>">
                <i class="mdi mdi-human menu-icon"></i>
                <span class="menu-title">Customers</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= url('admin/orders') ?>">
                <i class="mdi mdi-package-variant menu-icon"></i>
                <span class="menu-title">Orders</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= url('admin/suppliers') ?>">
                <i class="mdi mdi-motorbike menu-icon"></i>
                <span class="menu-title">Suppliers</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= url('admin/type') ?>">
                <i class="mdi mdi-motorbike menu-icon"></i>
                <span class="menu-title">Job Type</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= url('admin/stock_history') ?>">
                <i class="mdi mdi-clipboard-outline menu-icon"></i>
                <span class="menu-title">Stock History</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= url('admin/feedback') ?>">
                <i class="mdi mdi-message-processing menu-icon"></i>
                <span class="menu-title">Feedbacks</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= url('admin/pages') ?>">
                <i class="mdi mdi-file-document-box-outline menu-icon"></i>
                <span class="menu-title">Pages</span>
            </a>
        </li>
    </ul>
</nav>
