<?php
//remove last character from string
$pageTitle = $entity->table;
$link = strtolower($pageTitle);
$entity->setReturnTypeArr();
$id = @$_GET['id'];
$item = [];
if ($id) {
    $item = $entity->find($id);
}
?>
<div class="main-panel" style="height: 80vh;overflow-y:scroll;">
    <main>
        <div class="content-wrapper">
            <div class="col-12formData grid-margin">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">
                            <?php if ($id): ?>Edit <?php else: ?> Add <?php endif; ?> <?= $pageTitle ?>
                        </h4>
                        <form class="form-sample" method="post" enctype="multipart/form-data">
                            <input type="hidden" class="form-control" name="<?= $entity->getIdAttribute() ?>" value="<?= @$item[$entity->getIdAttribute()] ?>"  >
                            <p class="card-description">
                                <?= $pageTitle ?> info
                            </p>
                            <div class="row">
                                <?php foreach ($form as $element): ?>
                                    <div class="<?php if(@$element['full-col'] || $element['type'] == 'hidden'): ?>col-md-12<?php else: ?> col-md-6 <?php endif;?>">
                                        <?php if($element['type'] == 'hidden'): ?>
                                             <input type="hidden" class="form-control" name="<?= $element['name'] ?>" value="<?= @$item[$element['name']] ?>" <?= @$element['required'] ? 'required' : '' ?>   placeholder="<?= @$element['placeholder'] ?>" >
                                        <?php else: ?>
                                             <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">
                                                    <?= $element['label'] ?>
                                                </label>
                                                <div class="col-sm-9">
                                                    <?php if ($element['type'] == 'text'): ?>
                                                        <input type="text" class="form-control" name="<?= $element['name'] ?>" value="<?= @$item[$element['name']] ?>" <?= @$element['required'] ? 'required' : '' ?> placeholder="<?= @$element['placeholder'] ?>">
                                                    <?php elseif ($element['type'] == 'number'): ?>
                                                        <input type="number" class="form-control" name="<?= $element['name'] ?>" value="<?= @$item[$element['name']] ?>"  <?= @$element['required'] ? 'required' : '' ?>  placeholder="<?= @$element['placeholder'] ?>">
                                                    <?php elseif ($element['type'] == 'select'): ?>
                                                        <select class="form-control" name="<?= $element['name'] ?>"  <?= @$element['required'] ? 'required' : '' ?> placeholder="<?= @$element['placeholder'] ?>" >
                                                            <?php foreach ($element['options'] as $option): ?>
                                                                <option value="<?= @$option['value'] ?>" <?= @$item[$element['name']] == @$option['value'] ? 'selected' : '' ?> >
                                                                    <?= @$option['label'] ?>
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    <?php elseif ($element['type'] == 'textarea'): ?>
                                                        <textarea class="form-control" rows="10" name="<?= $element['name'] ?>" <?= @$element['required'] ? 'required' : '' ?>  placeholder="<?= @$element['placeholder'] ?>"><?= @$item[$element['name']] ?></textarea>
                                                    <?php elseif ($element['type'] == 'file'): ?>
                                                        <input type="file" class="form-control" name="<?= $element['name'] ?>" <?= @$element['required'] ? 'required' : '' ?>   placeholder="<?= @$element['placeholder'] ?>" >
                                                    <?php elseif ($element['type'] == 'checkbox'): ?>
                                                         <div class="flex justify-content-center align-items-center py-3">
                                                             <input type="checkbox" class="form-check-input" name="<?= $element['name'] ?>" <?= @$element['required'] ? 'required' : '' ?>   placeholder="<?= @$element['placeholder'] ?>"  <?= @$item[$element['name']] == 1 ? 'checked' : '' ?> >
                                                         </div>
                                                    <?php elseif ($element['type'] == 'date'): ?>
                                                        <input type="date" class="form-control" name="<?= $element['name'] ?>" value="<?= @$item[$element['name']] ?>" <?= @$element['required'] ? 'required' : '' ?>   placeholder="<?= @$element['placeholder'] ?>" >
                                                    <?php elseif ($element['type'] == 'rich_text_box'): ?>
                                                        <input name="<?= $element['name'] ?>" id="editor_<?= $element['name'] ?>" type="hidden" value="<?= @$item[$element['name']] ?>">
                                                        <div class="p-4 mb-4">
                                                            <div  id="editor" style="height: 300px;" input-name="<?= $element['name'] ?>">
                                                                <?= @$item[$element['name']] ?>
                                                            </div>
                                                        </div>
                                                    <?php elseif ($element['type'] == 'password'): ?>
                                                        <input type="password" class="form-control" name="<?= $element['name'] ?>" <?= @$element['required'] ? 'required' : '' ?>   placeholder="<?= @$element['placeholder'] ?>" >
                                                    <?php elseif ($element['type'] == 'time'): ?>
                                                        <input  type="time" name="<?= $element['name'] ?>" <?= @$element['required'] ? 'required' : '' ?>   placeholder="<?= @$element['placeholder'] ?>" value="<?= @$item[$element['name']] ?>">
                                                    <?php endif; ?>
                                                </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                             </div>
                            <div class="mb-3 d-flex flex-column justify-content-center">
                                <button type="submit" class="btn btn-primary mb-3 text-white" style="margin: 0 auto;">
                                    Submit
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- cotent-wrapper ends -->
    <!-- partial:partials/_footer.html -->
    <footer class="footer">
        <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <a href="https://www.bootstrapdash.com/" target="_blank">Sarvello fine foods </a>2023</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Only the best <a href="https://www.bootstrapdash.com/" target="_blank"> Bootstrap dashboard  </a> templates</span>
        </div>
    </footer>
    <!-- partial -->
</div>