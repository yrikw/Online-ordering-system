<?php
// Dummy data for weekly reports
$weeklyReports = [
    ['month' => 'January', 'sales' => 15000, 'customers' => 100],
    ['month' => 'February', 'sales' => 18000, 'customers' => 120],
    ['month' => 'March', 'sales' => 20000, 'customers' => 150],
    ['month' => 'April', 'sales' => 22000, 'customers' => 140],
    ['month' => 'May', 'sales' => 19000, 'customers' => 110],
    ['month' => 'June', 'sales' => 23000, 'customers' => 160],
    ['month' => 'July', 'sales' => 25000, 'customers' => 180],
    ['month' => 'August', 'sales' => 21000, 'customers' => 130],
    ['month' => 'September', 'sales' => 24000, 'customers' => 170],
    ['month' => 'October', 'sales' => 28000, 'customers' => 200],
];

// Generate dummy data for the chart
$chartData = [];
foreach ($weeklyReports as $report) {
    $chartData[] = [
        'month' => $report['month'],
        'sales' => $report['sales'],
        'customers' => $report['customers'],
    ];
}
?>

<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
<div class="container-fluid page-body-wrapper">
    <?php component('admin.inc.sidebar'); ?>
    <div class="main-panel">
        <main>
            <div class="content-wrapper">
                <div class="row">
                    <div class="col-md-12 grid-margin">
                        <div class="d-flex justify-content-between flex-wrap">
                            <div class="d-flex align-items-end flex-wrap">
                                <div class="d-flex">
                                    <i class="mdi mdi-home text-muted hover-cursor"></i>
                                    <p class="text-muted mb-0">&nbsp;/&nbsp;Reports&nbsp;/&nbsp;Weekly Reports&nbsp;&nbsp;</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container d-flex">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Month</th>
                                    <th>Sales</th>
                                    <th>Number of Customers</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($weeklyReports as $report): ?>
                                    <tr>
                     <td class="text-center"><?= $report['month'] ?></td>
                     <td class="text-center"><?= $report['sales'] ?></td>
                     <td class="text-center"><?= $report['customers'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="chart-container">
                        <canvas id="monthlyChart" width="600" height="300"></canvas>
                    </div>
                </div>
                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                <script>
                    const salesData = <?= json_encode($chartData) ?>;
                    const ctx = document.getElementById('monthlyChart').getContext('2d');
                    const chart = new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: salesData.map(data => data.month),
                            datasets: [{
                                label: 'Sales',
                                data: salesData.map(data => data.sales),
                                backgroundColor: 'rgba(0, 123, 255, 0.5)',
                                borderColor: 'rgba(0, 123, 255, 0.8)',
                                borderWidth: 1
                            }, {
                                label: 'Customers',
                                data: salesData.map(data => data.customers),
                                backgroundColor: 'rgba(0, 186, 90, 0.5)',
                                borderColor: 'rgba(0, 186, 90, 0.8)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                x: {
                                    display: true,
                                    title: {
                                        display: true,
                                        text: 'Month'
                                    }
                                },
                                y: {
                                    display: true,
                                    title: {
                                        display: true,
                                        text: 'Value'
                                    }
                                }
                            }
                        }
                    });
                </script>
            </div>
        </main>

        <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">&copy; 2023 Sarvello fine foods</span>
                <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Only the best <a href="https://www.bootstrapdash.com/" target="_blank">Bootstrap dashboard</a> templates</span>
            </div>
        </footer>
    </div>
</div>
<?php component('admin.inc.footer'); ?>
