<?php
// Dummy data for orders
$orders = [
    ['id' => 10],
    ['id' => 15],
    ['id' => 20],
    ['id' => 05],
    ['id' => 25],
    ['id' => 30],
    // Add more dummy values for each week
];

// Dummy data for customers
$customers = [
    ['id' => 5],
    ['id' => 8],
    ['id' => 12],
    ['id' => 17],
    ['id' => 28],
    ['id' => 11],
    // Add more dummy values for each week
];

$length = count($orders); // Assuming $orders and $customers have the same length
?>

<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
<div class="container-fluid page-body-wrapper">
    <?php component('admin.inc.sidebar'); ?>
    <div class="main-panel">
        <main>
            <div class="content-wrapper">
                <div class="row">
                    <div class="col-md-12 grid-margin">
                        <div class="d-flex justify-content-between flex-wrap">
                            <div class="d-flex align-items-end flex-wrap">
                                <div class="d-flex">
                                    <i class="mdi mdi-home text-muted hover-cursor"></i>
                                    <p class="text-muted mb-0">&nbsp;/&nbsp;Reports&nbsp;/&nbsp;Weekly Reports&nbsp;&nbsp;</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="container d-flex">
                    <div class="table-container">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th class="text-center">Week Number</th>
                                    <th class="text-center">Orders</th>
                                    <th class="text-center">Number of Customers</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php for ($i = 1; $i <= $length; $i++): ?>
                                    <tr>
                                        <td class="text-center"><?= $i ?></td>
                                        <td class="text-center"><?= @$orders[$i - 1]['id'] ?></td>
                                        <td class="text-center"><?= @$customers[$i - 1]['id'] ?></td>
                                    </tr>
                                <?php endfor; ?>
                                <!-- Add more rows for each week -->
                            </tbody>
                        </table>
                    </div>
                    <div class="chart-container">
                        <canvas id="salesChart" width="605" height="302" style="display: block; box-sizing: border-box; height: 302px; width: 605px;"></canvas>
                    </div>
                </div>
                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                <script>
                    // Sample data for the chart
                    const salesData = [
                        <?php for ($i = 1; $i <= $length; $i++): ?>
                            {
                                week: <?= $i ?>,
                                sales: <?= @$orders[$i - 1]['id'] ?>,
                                customers: <?= @$customers[$i - 1]['id'] ?>
                            },
                        <?php endfor; ?>
                    ];

                    // Chart configuration
                    const salesChartConfig = {
                        type: 'line',
                        data: {
                            labels: salesData.map(data => data.week),
                            datasets: [
                                {
                                    label: 'Orders',
                                    data: salesData.map(data => data.sales),
                                    borderColor: 'rgb(0, 123, 255)',
                                    backgroundColor: 'rgba(0, 123, 255, 0.1)',
                                    fill: true
                                },
                                {
                                    label: 'Customers',
                                    data: salesData.map(data => data.customers),
                                    borderColor: 'rgb(255, 193, 7)',
                                    backgroundColor: 'rgba(255, 193, 7, 0.1)',
                                    fill: true
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            scales: {
                                x: {
                                    display: true,
                                    title: {
                                        display: true,
                                        text: 'Week Number'
                                    }
                                },
                                y: {
                                    display: true,
                                    title: {
                                        display: true,
                                        text: 'Count'
                                    }
                                }
                            }
                        }
                    };

                    // Create the chart
                    const salesChartCtx = document.getElementById('salesChart').getContext('2d');
                    new Chart(salesChartCtx, salesChartConfig);
                </script>

                <!-- Rest of the code -->

            </div>
        </main>

        <!-- cotent-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Sarvello fine foods &copy; 2023</span>
                <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Only the best Bootstrap dashboard templates</span>
            </div>
        </footer>
        <!-- partial -->
    </div>
</div>
<?php component('admin.inc.footer'); ?>
