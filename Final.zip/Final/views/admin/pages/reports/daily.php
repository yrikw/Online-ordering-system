<?php
// Dummy data for daily reports
$dailyReports = [
    ['date' => '2023-05-24', 'day' => 'Wednesday', 'sales' => 1500, 'customers' => 10],
    ['date' => '2023-05-25', 'day' => 'Thursday', 'sales' => 1800, 'customers' => 12],
    ['date' => '2023-05-26', 'day' => 'Friday', 'sales' => 2000, 'customers' => 15],
    ['date' => '2023-05-27', 'day' => 'Saturday', 'sales' => 2200, 'customers' => 14],
    ['date' => '2023-05-28', 'day' => 'Sunday', 'sales' => 1900, 'customers' => 11],
    ['date' => '2023-05-29', 'day' => 'Monday', 'sales' => 2300, 'customers' => 16],
    ['date' => '2023-05-30', 'day' => 'Tuesday', 'sales' => 2500, 'customers' => 18],
    ['date' => '2023-05-31', 'day' => 'Wednesday', 'sales' => 2100, 'customers' => 13],
    ['date' => '2023-06-01', 'day' => 'Thursday', 'sales' => 2400, 'customers' => 17],
    ['date' => '2023-06-02', 'day' => 'Friday', 'sales' => 2800, 'customers' => 20],
];

// Generate dummy data for the chart
$chartData = [];
foreach ($dailyReports as $report) {
    $chartData[] = [
        'date' => $report['date'],
        'sales' => $report['sales'],
        'customers' => $report['customers'],
    ];
}
?>

<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
<div class="container-fluid page-body-wrapper">
    <?php component('admin.inc.sidebar'); ?>
    <div class="main-panel">
        <main>
            <div class="content-wrapper">
                <div class="row">
                    <div class="col-md-12 grid-margin">
                        <div class="d-flex justify-content-between flex-wrap">
                            <div class="d-flex align-items-end flex-wrap">
                                <div class="d-flex">
                                    <i class="mdi mdi-home text-muted hover-cursor"></i>
                                    <p class="text-muted mb-0">&nbsp;/&nbsp;Reports&nbsp;/&nbsp;Daily Reports&nbsp;&nbsp;</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container d-flex">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th style="width: 150px;">Date</th>
                                    <th>Day</th>
                                    <th style="width: 150px;">Sales in $</th>
                                    <th>No. of Customers</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($dailyReports as $report): ?>
                                    <tr>
                                        <td><?= $report['date'] ?></td>
                                        <td><?= $report['day'] ?></td>
                                        <td><?= $report['sales'] ?></td>
                                        <td><?= $report['customers'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="chart-container" style="width: 450px;">
                        <canvas id="dailyChart" width="200" height="100"></canvas>
                    </div>
                </div>
                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                <script>
                    const salesData = <?= json_encode($chartData) ?>;
                    const ctx = document.getElementById('dailyChart').getContext('2d');
                    const chart = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: salesData.map(data => data.date),
                            datasets: [{
                                label: 'Sales',
                                data: salesData.map(data => data.sales),
                                backgroundColor: 'rgba(0, 123, 255, 0.1)',
                                borderColor: 'rgba(0, 123, 255, 0.8)',
                                borderWidth: 1,
                                fill: true
                            }, {
                                label: 'Customers',
                                data: salesData.map(data => data.customers),
                                backgroundColor: 'rgba(0, 186, 90, 0.1)',
                                borderColor: 'rgba(0, 186, 90, 0.8)',
                                borderWidth: 1,
                                fill: true
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                x: {
                                    display: true,
                                    title: {
                                        display: true,
                                        text: 'Date'
                                    }
                                },
                                y: {
                                    display: true,
                                    title: {
                                        display: true,
                                        text: 'Value'
                                    }
                                }
                            }
                        }
                    });
                </script>
            </div>
        </main>

        <!-- cotent-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">&copy; 2023 Sarvello fine foods</span>
                <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Only the best <a href="https://www.bootstrapdash.com/" target="_blank">Bootstrap dashboard</a> templates</span>
            </div>
        </footer>
        <!-- partial -->
    </div>
</div>
<?php component('admin.inc.footer'); ?>
<style>
    .table {
        width: 100%;
        border-collapse: collapse;
    }

    .table th,
    .table td {
        padding: 8px;
        text-align: center;
    }

    .table thead th {
        background-color: #f5f5f5;
    }

    .table tbody tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .chart-container {
        margin-left: 20px;
    }
</style>
