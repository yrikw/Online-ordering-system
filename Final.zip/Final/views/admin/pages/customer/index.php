<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
    <div class="container-fluid page-body-wrapper">
        <?php component('admin.inc.sidebar'); ?>
        <?php component('admin.inc.itemListing',[
            'entity' => $model,
            'tableColumns' => [
                    [
                         "label"=>"ID",
                         "field"=>"customer_id"
                    ],
                    [
                        "label"=>"Family Name",
                        "field"=>"family_name"
                    ],
                    [
                        "label"=>"First Name",
                        "field"=>"first_name",
                    ],
                    [
                        "label"=>"Phone No",
                        "field"=>"phone_no"
                    ],
                    [
                        "label"=>"Email",
                        "field"=>"email"
                    ],
                    [
                        "label"=>"Address",
                        "field"=>"address"
                    ],
                    [
                        "label"=>"Date of Birth",
                        "field"=>"date_of_birth"
                    ],
                    [
                        "label"=>"Job Type",
                        "field"=>"job_type_id",
                        "render"=> function($id){
                            $model = new \app\models\JobType();
                            $record = $model->find($id);
                            return $record->name;
                        }
                    ],
            ],
            'tableActions' => ['add','edit', 'delete'],
            'breadcumbs' => ['Admin', 'Products']
        ]); ?>
    </div>
</div>
<?php component('admin.inc.footer'); ?>
