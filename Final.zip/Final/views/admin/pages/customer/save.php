<?php
$jobType = new \app\models\JobType();
?>
<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
<div class="container-fluid page-body-wrapper">
    <?php component('admin.inc.sidebar'); ?>
    <?php component('admin.inc.formData',[
        'entity' => $model,
        'form' => [
            [
                "label"=>"Family Name",
                "name"=>"family_name",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Family Name",
            ],
            [
                "label"=>"First Name",
                "name"=>"first_name",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"First Name",
            ],
            [
                "label"=>"Phone No",
                "name"=>"phone_no",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Phone No",
            ],
            [
                "label"=>"Address",
                "name"=>"address",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Address",
            ],
            [
                "label"=>"Date of Birth",
                "name"=>"date_of_birth",
                "type"=>"date",
                "required"=>true,
                "placeholder"=>"Date of Birth",
            ],
            [
                "label"=>"Job Type",
                "name"=>"job_type_id",
                "type"=>"select",
                "required"=>true,
                "placeholder"=>"Job Type",
                "options" =>  toOptionList($jobType->all(), 'job_type_id', 'name'),
            ],
            [
                "label"=>"Email",
                "name"=>"email",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Email",
            ],
            [
                "label"=>"Password",
                "name"=>"password",
                "type"=>"password",
                "required"=>true,
                "placeholder"=>"Password",
            ],
        ],
        'tableActions' => ['add','edit', 'delete'],
        'breadcumbs' => ['Admin', 'Customers']
    ]); ?>
</div>
<?php component('admin.inc.footer'); ?>
