<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
    <div class="container-fluid page-body-wrapper">
        <?php component('admin.inc.sidebar'); ?>
        <?php component('admin.inc.itemListing',[
            'entity' => $model,
            'tableColumns' => [
                    [
                         "label"=>"ID",
                         "field"=>"job_type_id"
                    ],
                    [
                        "label"=>"Name",
                        "field"=>"name"
                    ],
            ],
            'tableActions' => ['add','edit', 'delete'],
            'breadcumbs' => ['Admin', 'Job Types']
        ]); ?>
    </div>
</div>
<?php component('admin.inc.footer'); ?>
