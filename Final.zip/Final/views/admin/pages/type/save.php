<?php
$qualification = new \app\models\Qualification();
?>
<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
<div class="container-fluid page-body-wrapper">
    <?php component('admin.inc.sidebar'); ?>
    <?php component('admin.inc.formData',[
        'entity' => $model,
        'form' => [
            [
                "label"=>"Name",
                "name"=>"name",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Family Name",
            ],
        ],
        'tableActions' => ['add','edit', 'delete'],
        'breadcumbs' => ['Admin', 'Job Types']
    ]); ?>
</div>
<?php component('admin.inc.footer'); ?>
