<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
    <div class="container-fluid page-body-wrapper">
        <?php component('admin.inc.sidebar'); ?>
        <?php component('admin.inc.itemListing',[
            'entity' => $model,
            'tableColumns' => [
                    [
                         "label"=>"ID",
                         "field"=>"supplier_id"
                    ],
                    [
                        "label"=>"Name",
                        "field"=>"name",
                    ],
                    [
                         "label"=>"Phone No",
                         "field"=>"phone_no"
                    ],
                    [
                         "label"=>"Email",
                         "field"=>"email"
                    ],
                    [
                         "label"=>"Address",
                         "field"=>"address"
                    ],
            ],
            'tableActions' => ['add','edit', 'delete'],
            'breadcumbs' => ['Admin', 'Products']
        ]); ?>
    </div>
</div>
<?php component('admin.inc.footer'); ?>
