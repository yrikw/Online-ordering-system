<?php
$customers = new \app\models\Customer();
?>
<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
<div class="container-fluid page-body-wrapper">
    <?php component('admin.inc.sidebar'); ?>
    <?php component('admin.inc.formData',[
        'entity' => $model,
        'form' => [
            [
                "label"=>"Name",
                "name"=>"name",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Name",
            ],
            [
                "label"=>"Registration No",
                "name"=>"registration_no",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Name",
            ],
            [
                "label"=>"Phone No",
                "name"=>"phone_no",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Name",
            ],
            [
                "label"=>"Email",
                "name"=>"email",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Email",
            ],
            [
                "label"=>"Address",
                "name"=>"address",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Address",
            ],
        ],
        'tableActions' => ['add','edit', 'delete'],
        'breadcumbs' => ['Admin', 'Suppliers']
    ]); ?>
</div>
<?php component('admin.inc.footer'); ?>
