<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
    <div class="container-fluid page-body-wrapper">
        <?php component('admin.inc.sidebar'); ?>
        <?php component('admin.inc.itemListing',[
            'entity' => $model,
            'tableColumns' => [
                    [
                         "label"=>"ID",
                         "field"=>"feedback_id"
                    ],
                    [
                        "label"=>"Customer",
                        "field"=>"customer_id",
                        "render"=> function($customer_id){
                            $model = new \app\models\Customer();
                            $customer = $model->find($customer_id);
                            return $customer->first_name." ".$customer->family_name;
                        }
                    ],
                    [
                        "label"=>"Product",
                        "field"=>"product_id",
                        "render"=> function($product_id){
                            $model = new \app\models\Product();
                            $product = $model->find($product_id);
                            return $product->name;
                        }
                    ],
                    [
                        "label"=>"Title",
                        "field"=>"title",
                    ],
                    [
                        "label"=>"Feedback",
                        "field"=>"feedback",
                    ],
            ],
            'tableActions' => ['delete'],
            'breadcumbs' => ['Admin', 'Products']
        ]); ?>
    </div>
</div>
<?php component('admin.inc.footer'); ?>
