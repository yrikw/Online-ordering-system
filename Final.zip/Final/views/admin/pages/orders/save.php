<?php
$customers = new \app\models\Customer();
$staff = new \app\models\Staff();
?>
<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
<div class="container-fluid page-body-wrapper">
    <?php component('admin.inc.sidebar'); ?>
    <?php component('admin.inc.formData',[
        'entity' => $model,
        'form' => [
            [
                "label"=>"Customer",
                "name"=>"customer_id",
                "type"=>"select",
                "required"=>true,
                "placeholder"=>"Select Customer",
                "options"=>toOptionList($customers->all(), 'customer_id', 'first_name','family_name')
            ],
            [
                "label"=>"Pickup Date",
                "name"=>"pickup_date",
                "type"=>"date",
                "required"=>true,
                "placeholder"=>"Enter Pickup Date",
            ],
            [
                "label"=>"Pickup Time",
                "name"=>"time",
                "type"=>"time",
                "required"=>true,
                "placeholder"=>"Enter Pickup Time",
            ],
             // staff_id
            [
                "label"=>"Staff",
                "name"=>"staff_id",
                "type"=>"select",
                "required"=>true,
                "placeholder"=>"Select Staff",
                "options"=>toOptionList($staff->all(), 'staff_id', 'first_name','family_name')
            ],
//            delivery
            [
                "label"=>"Delivery",
                "name"=>"status",
                "type"=>"select",
                "required"=>true,
                "placeholder"=>"Select Status",
                "options"=>[
                    [
                        "label"=>"Pending",
                        "value"=>0
                    ],
                    [
                        "label"=>"Completed",
                        "value"=>1
                    ]
                ]
            ],
            [
                "label"=>"Status",
                "name"=>"status",
                "type"=>"select",
                "required"=>true,
                "placeholder"=>"Select Status",
                "options"=>[
                    [
                        "label"=>"Pending",
                        "value"=>"pending"
                    ],
                    [
                        "label"=>"Completed",
                        "value"=>"completed"
                    ],
                    [
                        "label"=>"Cancelled",
                        "value"=>"cancelled"
                    ],
                ]
            ],
        ],
        'tableActions' => ['edit', 'delete'],
        'breadcumbs' => ['Admin', 'Products']
    ]); ?>
</div>
<?php component('admin.inc.footer'); ?>
