<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
    <div class="container-fluid page-body-wrapper">
        <?php component('admin.inc.sidebar'); ?>
        <?php component('admin.inc.itemListing',[
            'entity' => $model,
            'tableColumns' => [
                    [
                         "label"=>"ID",
                         "field"=>"order_id"
                    ],
                    [
                        "label"=>"Customer",
                        "field"=>"customer_id",
                        "render"=> function($id){
                            $model = new \app\models\Customer();
                            $record = $model->find($id);
                            return $record->first_name . ' ' . $record->family_name;
                        }
                    ],
                    [
                         "label"=>"Pickup Date",
                         "field"=>"pickup_date"
                    ],
                    [
                        "label"=>"Pickup Time",
                        "field"=>"time"
                    ],
                [
                        "label"=>"Status",
                        "field"=>"status",

                ]
            ],
            'tableActions' => ['add','edit', 'delete'],
            'breadcumbs' => ['Admin', 'Products']
        ]); ?>
    </div>
</div>
<?php component('admin.inc.footer'); ?>
