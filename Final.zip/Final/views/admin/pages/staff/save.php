<?php
$qualification = new \app\models\Qualification();
?>
<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
<div class="container-fluid page-body-wrapper">
    <?php component('admin.inc.sidebar'); ?>
    <?php component('admin.inc.formData',[
        'entity' => $model,
        'form' => [
            [
                "label"=>"Family Name",
                "name"=>"family_name",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Family Name",
            ],
            [
                "label"=>"First Name",
                "name"=>"first_name",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"First Name",
            ],
            [
                "label"=>"Phone No",
                "name"=>"phone_no",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Phone No",
            ],
            [
                "label"=>"Email",
                "name"=>"email",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Email",
            ],
            [
                "label"=>"Qualification",
                "name"=>"qualification_id",
                "type"=>"select",
                "required"=>true,
                "placeholder"=>"Qualification",
                "options" =>  toOptionList($qualification->all(), 'qualification_id', 'name'),
            ],
            [
                "label"=>"Working Hour",
                "name"=>"working_hour",
                "type"=>"number",
                "required"=>true,
                "placeholder"=>"Working Hour",
            ],
            [
                "label"=>"Pay",
                "name"=>"pay",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Pay",
            ],
        ],
        'tableActions' => ['add','edit', 'delete'],
        'breadcumbs' => ['Admin', 'Products']
    ]); ?>
</div>
<?php component('admin.inc.footer'); ?>
