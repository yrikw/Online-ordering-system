<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
    <div class="container-fluid page-body-wrapper">
        <?php component('admin.inc.sidebar'); ?>
        <?php component('admin.inc.itemListing',[
            'entity' => $model,
            'tableColumns' => [
                    [
                         "label"=>"ID",
                         "field"=>"product_id"
                    ],
                    [
                        "label"=>"Image",
                        "field"=>"image_pathlocation",
                        "type"=>"image"
                    ],
                    [
                         "label"=>"Name",
                         "field"=>"name"
                    ],
                    [
                         "label"=>"Price",
                         "field"=>"price"
                    ],
                    [
                         "label"=>"Quantity",
                         "field"=>"quantity"
                    ],
                    [
                         "label"=>"Category",
                         "field"=>"category_id",
                        "render"=> function($id){
                            $model = new \app\models\Category();
                            $record = $model->find($id);
                            return $record->name;
                        }
                    ],
            ],
            'tableActions' => ['add','edit', 'delete'],
            'breadcumbs' => ['Admin', 'Products']
        ]); ?>
    </div>
</div>
<?php component('admin.inc.footer'); ?>
