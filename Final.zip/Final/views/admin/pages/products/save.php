<?php
$categories = new \app\models\Category();
$suppliers = new \app\models\Supplier();
?>
<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
<div class="container-fluid page-body-wrapper">
    <?php component('admin.inc.sidebar'); ?>
    <?php component('admin.inc.formData',[
        'entity' => $model,
        'form' => [
            [
                "label"=>"Name",
                "name"=>"name",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Enter Product Name",
            ],
            [
                "label"=>"Category",
                "name"=>"category_id",
                "type"=>"select",
                "required"=>true,
                "placeholder"=>"Select Category",
                "options"=>toOptionList($categories->all(), 'category_id', 'name')
            ],
            [
                "label"=>"Price",
                "name"=>"price",
                "type"=>"text",
                "required"=>true,
                "placeholder"=>"Price",
            ],
            [
                "label"=>"Mfg. Date",
                "name"=>"mfg_date",
                "type"=>"date",
                "required"=>true,
                "placeholder"=>"Mfg. Date",
            ],
            [
                "label"=>"Expiry",
                "name"=>"expiry_date",
                "type"=>"date",
                "required"=>true,
                "placeholder"=>"Expiry Date (YYYY/MM/DD)" ,
            ],
            [
                "label"=>"Supplier",
                "name"=>"supplier_id",
                "type"=>"select",
                "required"=>true,
                "placeholder"=>"Select Supplier",
                "options"=>toOptionList($suppliers->all(), 'supplier_id', 'name')
            ],
            [
                "label"=>"Quantity",
                "name"=>"quantity",
                "type"=>"number",
                "required"=>true,
                "placeholder"=>"Quantity",
            ],
            [
                "label"=>"Weekly Sale",
                "name"=>"weekly_sale",
                "type"=>"number",
                "required"=>true,
                "placeholder"=>"Weekly Sale",
            ],
            [
                "label"=>"Feature",
                "name"=>"Featureed_product",
                "type"=>"checkbox",
                "required"=>false,
                "full-col"=>true,
            ],
            [
                "label"=>"File upload",
                "name"=>"image_pathlocation",
                "type"=>"file",
                "required"=>false,
                "placeholder"=>"Upload Image",
            ],
            [
                "label"=>"Description",
                "name"=>"description",
                "type"=>"textarea",
                "required"=>true,
                "full-col"=>true,
                "placeholder"=>"Description",
            ],
        ],
        'tableActions' => ['add','edit', 'delete'],
        'breadcumbs' => ['Admin', 'Products']
    ]); ?>
</div>
<?php component('admin.inc.footer'); ?>

