<?php
$suppliers = new \app\models\Supplier();
$products = new \app\models\Product();
?>
<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
<div class="container-fluid page-body-wrapper">
    <?php component('admin.inc.sidebar'); ?>
    <?php component('admin.inc.formData',[
        'entity' => $model,
        'form' => [
            [
                "label"=>"Supplier",
                "name"=>"supplier_id",
                "type"=>"select",
                "required"=>true,
                "placeholder"=>"Select Supplier",
                "options"=>toOptionList($suppliers->all(), 'supplier_id', 'name')
            ],
            [
                "label"=>"Product",
                "name"=>"product_id",
                "type"=>"select",
                "required"=>true,
                "placeholder"=>"Select Product",
                "options"=>toOptionList($products->all(), 'product_id', 'name')
            ],
            [
                "label"=>"Stock Date",
                "name"=>"stock_date",
                "type"=>"date",
                "required"=>true,
                "placeholder"=>"Stock Date",
            ],
            [
                "label"=>"Amount",
                "name"=>"amount",
                "type"=>"number",
                "required"=>true,
                "placeholder"=>"Amount",
            ],
        ],
        'tableActions' => ['add','edit', 'delete'],
        'breadcumbs' => ['Admin', 'Products']
    ]); ?>
</div>
<?php component('admin.inc.footer'); ?>
