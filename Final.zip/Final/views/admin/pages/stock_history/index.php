<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
    <div class="container-fluid page-body-wrapper">
        <?php component('admin.inc.sidebar'); ?>
        <?php component('admin.inc.itemListing',[
            'entity' => $model,
            'tableColumns' => [
                    [
                            "label"=>"ID",
                            "field"=>"history_id"
                    ],
                    [
                        "label"=>"Supplier",
                        "field"=>"supplier_id",
                        "render"=> function($id){
                            $model = new \app\models\Supplier();
                            $record = $model->find($id);
                            return $record->name;
                        }
                    ],
                    [
                        "label"=>"Product",
                        "field"=>"product_id",
                        "render"=> function($id){
                            $model = new \app\models\Product();
                            $record = $model->find($id);
                            return $record->name;
                        }
                    ],
                    [
                        "label"=>"Stock Date",
                        "field"=>"stock_date",
                    ],
                    [
                         "label"=>"Amount",
                         "field"=>"amount"
                    ],
            ],
            'tableActions' => ['add','edit', 'delete'],
            'breadcumbs' => ['Admin', 'Stock History']
        ]); ?>
    </div>
</div>
<?php component('admin.inc.footer'); ?>
