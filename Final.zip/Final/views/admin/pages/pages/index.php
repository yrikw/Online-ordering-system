<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
    <div class="container-fluid page-body-wrapper">
        <?php component('admin.inc.sidebar'); ?>
        <?php component('admin.inc.itemListing',[
            'entity' => $model,
            'tableColumns' => [
                [
                    "label"=>"ID",
                    "field"=>"id"
                ],
                [
                    "label"=>"Title",
                    "field"=>"title"
                ],
                [
                    "label"=>"Slug",
                    "field"=>"slug"
                ],
            ],
            'tableActions' => ['add','edit', 'delete'],
            'breadcumbs' => ['Admin', 'Page']
        ]); ?>
    </div>
</div>
<?php component('admin.inc.footer'); ?>
