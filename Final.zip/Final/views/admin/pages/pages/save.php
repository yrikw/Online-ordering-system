<?php component('admin.inc.header'); ?>
<?php component('admin.inc.navbar'); ?>
    <div class="container-fluid page-body-wrapper">
        <?php component('admin.inc.sidebar'); ?>
        <?php component('admin.inc.formData',[
            'entity' => $model,
            'form' => [
                [
                    "label"=>"title",
                    "name"=>"title",
                    "type"=>"text",
                    "required"=>true,
                    "full-col"=>true,
                    "placeholder"=>"Title",
                ],
                [
                    "label"=>"Content",
                    "name"=>"content",
                    "type"=>"rich_text_box",
                    "required"=>true,
                    "placeholder"=>"Content",
                    "full-col"=>true,
                ],
                [
                    "label"=>"slug",
                    "name"=>"slug",
                    "type"=>"text",
                    "required"=>true,
                    "full-col"=>true,
                    "placeholder"=>"Slug",
                ],
            ],
            'tableActions' => ['add','edit', 'delete'],
            'breadcumbs' => ['Admin', 'Pages']
        ]); ?>
    </div>
<?php component('admin.inc.footer'); ?>